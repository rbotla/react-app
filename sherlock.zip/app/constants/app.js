export const DEFAULT_LOCALE = 'en';
export const S3_DB_IMAGE_PREFIX = 'https://s3.amazonaws.com/edw-chc-prod-datasolutions/sherlock-web-app/images/dashboard_images/';
export const S3_DB_IMAGE_THUMBNAIL_PREFIX = 'https://s3.amazonaws.com/edw-chc-prod-datasolutions/sherlock-web-app/images/dashboard_thumbnails/';