export const DOMAIN = {
  development: 'https://ytfrcgixpi.execute-api.us-east-1.amazonaws.com/dev',
  production: 'https://ytfrcgixpi.execute-api.us-east-1.amazonaws.com/dev',
}[process.env.NODE_ENV];

export const ENDPOINTS = {
  DASHBOARDS: 'dashboards',
  SEARCH: 'dashboards/search',
  SEARCH_BY_LENS: 'dashboards/search/lens',
  SUPPORT: 'support',
};

export const HEADERS = {
  APPLICATION_JSON: new Headers({ Accept: 'application/json' }),
  APPLICATION_POST_JSON: { 
  	'Accept': 'application/json',
    'user-agent': 'Mozilla/4.0 MDN Example',
    'content-type': 'application/json',
//    'x-api-key': 'tVx2N2KCpP8w5qqb7q13G1KtRKfCs1nawt4Uzn2i', // key for EDW cloud 2.0 API Gateway
   },
};
