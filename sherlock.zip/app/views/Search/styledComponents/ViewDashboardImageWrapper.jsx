import styled from 'styled-components';
import { Colors } from '../../commonResources/colorVariables';
import Typography from '../../commonResources/typography';
import { BoxShadows } from '../../commonResources/boxShadows';
import { Borders } from '../../commonResources/borders';

export default styled.div`
    background-color: ${Colors.white};
    padding: 1.5em 2em;
    ${BoxShadows.lightFade};
    ${Borders.extraSmallBorderRadius};
    text-align: center;
  }
`