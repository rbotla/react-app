import styled from 'styled-components';

export const ButtonGroup = styled.div`
  text-align: right;
  margin: 0 1.5rem 10px 0;
  button {
    margin-right: 0.5rem;
  }
`;

export default ButtonGroup;
