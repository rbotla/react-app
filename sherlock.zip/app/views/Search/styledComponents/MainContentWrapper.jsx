import styled from 'styled-components';
import { LEFT_STRIP_EXPAND_COLLAPSE } from '../../commonResources/constants/timings';

export default styled.div`
  padding-left: ${props => props.leftStripPadding}px;
  transition: padding ${LEFT_STRIP_EXPAND_COLLAPSE}ms ease-in-out;
`;
