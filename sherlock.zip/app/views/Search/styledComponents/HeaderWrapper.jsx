import styled from 'styled-components';

export default styled.div`
  padding: .5rem 1.5rem 0 30px;
`;
