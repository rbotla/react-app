import styled from 'styled-components';

export default styled.div`
	display: flex;
	flex-direction: row;
  border-bottom: solid 1px #C4D0DA;
`;
