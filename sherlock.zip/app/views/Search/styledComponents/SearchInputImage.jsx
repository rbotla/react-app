import styled from 'styled-components';

export default styled.img`
  width: 13px;
  height: 13px;
  margin-top: 1px;
  margin-right: 8px;
`;
