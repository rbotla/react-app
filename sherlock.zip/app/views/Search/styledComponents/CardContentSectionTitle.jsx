import styled from 'styled-components';

export default styled.div`
  font-variant-caps: small-caps; 
  font-size: 1em;
`;