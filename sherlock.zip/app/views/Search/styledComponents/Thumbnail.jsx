import styled from 'styled-components';

export default styled.img`
  flex-grow: 1;
  width: 180px;
  height: 150px;
  padding: 5px;
  margin: 5px;
  max-width: 100%;
`;