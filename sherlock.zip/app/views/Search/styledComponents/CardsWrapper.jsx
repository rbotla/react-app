import styled from 'styled-components';

export default styled.div`
	display: grid;
	grid-gap: 1em;
	margin-bottom: 15px;
  padding: 0 1.5rem 0.4rem 30px;

	@media only screen and (min-width: 768px) {
		grid-template-columns: 1fr 1fr;
		-ms-grid-columns: 2;
	}

	@media only screen and (min-width: 1400px) {
		grid-template-columns: 1fr 1fr 1fr;
		-ms-grid-columns: 3;
	}

	@media only screen and (max-width: 767px) {
		grid-template-columns: 1fr;
	}

	@media only screen and (max-width: 767px) and (orientation: portrait) {
		grid-template-columns: 1fr 1fr;
	}


`;
