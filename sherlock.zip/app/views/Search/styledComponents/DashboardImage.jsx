import styled from 'styled-components';

export default styled.img`
  flex-grow: 1;
  align-content: center;
  padding: 5px;
  margin: 5px;
  max-width: 100%;
`;
