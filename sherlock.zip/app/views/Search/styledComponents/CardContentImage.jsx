import styled from 'styled-components';

export default styled.div`
	display: flex;
	flex-direction: column;
	flex: 1 1 auto;
	margin: 5px 0 0 5px;
`;
