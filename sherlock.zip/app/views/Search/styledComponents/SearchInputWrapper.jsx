import styled from 'styled-components';

export default styled.div`
  margin-bottom: 15px;
`;
