import { DOMAIN, ENDPOINTS, HEADERS } from '../../../constants/api';

export default {
  getAllDashboards: () => {
    return (
    fetch(`${DOMAIN}/${ENDPOINTS.DASHBOARDS}`,{ headers: HEADERS.APPLICATION_JSON })
      .then((fetchResponseObj) => {
        try {
          return fetchResponseObj.json();
        } catch (e) {
          return e;
        }
      })
    )
  },
  searchAll: (searchText) => {
    return (
    fetch(`${DOMAIN}/${ENDPOINTS.SEARCH}?q=${searchText}`, { headers: HEADERS.APPLICATION_JSON })
      .then((fetchResponseObj) => {
        try {
          return fetchResponseObj.json();
        } catch (e) {
          return e;
        }
      })
    )
  },
  searchByLens: (name, lens, ring1, ring2, ring3) => {
    const criteria = {};
    criteria['name'] = name;
    criteria['lens'] = lens;
    ring1 ? criteria['ring1'] = ring1 : null;
    ring2 ? criteria['ring2'] = ring2 : null;
    ring3 ? criteria['ring3'] = ring3 : null;
    const qs = Object.entries(criteria).map(x => x[0] + "=" + x[1]).join("&");

    return (
      fetch(`${DOMAIN}/${ENDPOINTS.SEARCH_BY_LENS}?${qs}`, { headers: HEADERS.APPLICATION_JSON })
        .then((fetchResponseObj) => {
          try {
            return fetchResponseObj.json();
          } catch (e) {
            return e;
          }
        })
    )
  },
  saveNewRequest: (data) => {
    let reqData = new Object();
    reqData['request_type'] = data.requestType;
    reqData['email'] = data.email;
    reqData['details'] = "Requesting access for " + data.dashboard + ". "+ data.requestDetails;
    return (
    fetch(`${DOMAIN}/${ENDPOINTS.SUPPORT}`,
        { headers: HEADERS.APPLICATION_POST_JSON,
          method: 'post',
          body: JSON.stringify(reqData) 
        }
      ).then((fetchResponseObj) => {
        try {
          return fetchResponseObj.json();
        } catch (e) {
          console.error(e)
          return e;
        }
      })
    )
  },
};
