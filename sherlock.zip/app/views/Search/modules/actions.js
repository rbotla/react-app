import {
  GET_ALL_DASHBOARDS_REQUESTED,
  GET_DASHBOARD_SEARCH_RESULTS_REQUESTED,
  ON_LEFT_STRIP_ADVANCE_ANIMATION,
  ON_LEFT_STRIP_RETREAT_ANIMATION,
  ON_VIEW_MODE_CHANGE,
  ON_VIEW_DASHBOARD,
  ON_BOOKMARK,
  ON_UNBOOKMARK,
  ON_LOADING_STATUS_CHANGE,
  ON_MULTI_SELECT_CHANGE,
  ON_ACCESS_REQUEST_OPEN,
  ON_ACCESS_REQUEST_CLOSE,
  ON_ACCESS_REQUEST_SUBMIT,
  ON_LENS_FILTER_SELECT,
} from './constants';

export const onAdvanceLeftStripAnimation = (state) => ({
  type: ON_LEFT_STRIP_ADVANCE_ANIMATION,
  state,
});

export const onRetreatLeftStripAnimation = (state) => ({
  type: ON_LEFT_STRIP_RETREAT_ANIMATION,
  state,
});

export const getAllDashboards = () => ({
  type: GET_ALL_DASHBOARDS_REQUESTED,
});

export const onDashboardSearch = (searchText) => ({
  type: GET_DASHBOARD_SEARCH_RESULTS_REQUESTED,
  searchText
});

export const onViewModeChange = (viewMode) => {
  return ({
  type: ON_VIEW_MODE_CHANGE,
  viewMode
  })
}

export const onViewDashboard = (dashboard) => {
  return ({
    type: ON_VIEW_DASHBOARD,
    dashboard
  })
}

export const onLoadingStatusChange = (status) => {
  return ({
    type: ON_LOADING_STATUS_CHANGE,
    status
  })
}

export const onMultiSelectChange = (isSectionHeader, sectionName, selectedItems) => {
  return ({
    type: ON_MULTI_SELECT_CHANGE,
    isSectionHeader,
    sectionName,
    selectedItems
  })
}

export const onAccessRequestSubmit = (data) => {
  return ({
    type: ON_ACCESS_REQUEST_SUBMIT,
    data
  })
}

export const onAccessRequestModalClose = () => {
  return ({
    type: ON_ACCESS_REQUEST_CLOSE
  })
}

export const onAccessRequestModalOpen = (dashboardName) => {
  return ({
    type: ON_ACCESS_REQUEST_OPEN,
    dashboardName
  })
}

export const onFilterByLens = (item) => {
  return ({
    type: ON_LENS_FILTER_SELECT,
    item
  })
}
