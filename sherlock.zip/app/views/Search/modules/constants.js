export const LEFT_STRIP_ANIM_STATES = {
  EXPANDED: 0,
  FADE_CONTENT: 1,
  EXPAND_COLLAPSE: 2,
  COLLAPSED: 3,
};

export const VIEW_MODES = {
  HOME: 0,
  SEARCH_RESULTS: 1,
  VIEW_DASHBOARD: 2,
};

export const ON_LOADING_STATUS_CHANGE = 'app/views/SearchResults/ON_LOADING_STATUS_CHANGE';

export const ON_LEFT_STRIP_ADVANCE_ANIMATION = 'app/views/SearchResults/ON_LEFT_STRIP_ADVANCE_ANIMATION';
export const ON_LEFT_STRIP_RETREAT_ANIMATION = 'app/views/SearchResults/ON_LEFT_STRIP_RETREAT_ANIMATION';

export const GET_ALL_DASHBOARDS_REQUESTED = 'app/views/SearchResults/GET_ALL_DASHBOARDS_REQUESTED';
export const GET_ALL_DASHBOARDS_SUCCEEDED = 'app/views/SearchResults/GET_ALL_DASHBOARDS_SUCCEEDED';
export const GET_ALL_DASHBOARDS_FAILED = 'app/views/SearchResults/GET_ALL_DASHBOARDS_FAILED';
export const GET_DASHBOARD_SEARCH_RESULTS_REQUESTED = 'app/views/SearchResults/GET_DASHBOARD_SEARCH_RESULTS_REQUESTED';
export const GET_DASHBOARD_SEARCH_RESULTS_SUCCEEDED = 'app/views/SearchResults/GET_DASHBOARD_SEARCH_RESULTS_SUCCEEDED';
export const GET_DASHBOARD_SEARCH_RESULTS_FAILED = 'app/views/SearchResults/GET_DASHBOARD_SEARCH_RESULTS_FAILED';
export const PUT_DASHBOARD_SEARCH_TEXT = 'app/views/SearchResults/PUT_DASHBOARD_SEARCH_TEXT';

export const ON_VIEW_MODE_CHANGE = 'app/views/SearchResults/ON_VIEW_MODE_CHANGE';
export const ON_VIEW_DASHBOARD = 'app/views/SearchResults/ON_VIEW_DASHBOARD';

export const ON_ACCESS_REQUEST_CLOSE = 'app/views/AppWrapper/ON_ACCESS_REQUEST_CLOSE';
export const ON_ACCESS_REQUEST_OPEN = 'app/views/AppWrapper/ON_ACCESS_REQUEST_OPEN';
export const ON_ACCESS_REQUEST_SUBMIT = 'app/views/AppWrapper/ON_ACCESS_REQUEST_SUBMIT';
export const ON_ACCESS_REQUEST_SUCCEEDED = 'app/views/AppWrapper/ON_ACCESS_REQUEST_SUCCEEDED';
export const ON_ACCESS_REQUEST_FAILED = 'app/views/AppWrapper/ON_ACCESS_REQUEST_FAILED';

export const ON_MULTI_SELECT_CHANGE = 'app/views/SearchResults/ON_MULTI_SELECT_CHANGE';

export const ON_LENS_FILTER_SELECT = 'app/views/SearchResults/ON_LENS_FILTER_SELECT';
export const ON_LENS_FILTER_SELECT_SUCCEEDED = 'app/views/SearchResults/ON_LENS_FILTER_SELECT_SUCCEEDED';
export const ON_LENS_FILTER_SELECT_FAILED = 'app/views/SearchResults/ON_LENS_FILTER_SELECT_FAILED';
