import { fromJS } from 'immutable';
import {
  GET_ALL_DASHBOARDS_SUCCEEDED,
  GET_ALL_DASHBOARDS_FAILED,
  GET_DASHBOARD_SEARCH_RESULTS_SUCCEEDED,
  GET_DASHBOARD_SEARCH_RESULTS_FAILED,
  ON_LEFT_STRIP_ADVANCE_ANIMATION,
  ON_LEFT_STRIP_RETREAT_ANIMATION,
  PUT_DASHBOARD_SEARCH_TEXT,
  LEFT_STRIP_ANIM_STATES,
  VIEW_MODES,
  ON_VIEW_MODE_CHANGE,
  ON_VIEW_DASHBOARD,
  ON_BOOKMARK,
  ON_UNBOOKMARK,
  ON_LOADING_STATUS_CHANGE,
  ON_MULTI_SELECT_CHANGE,
  ON_ACCESS_REQUEST_CLOSE,
  ON_ACCESS_REQUEST_SUCCEEDED,
  ON_ACCESS_REQUEST_FAILED,
  ON_ACCESS_REQUEST_OPEN,
  ON_LENS_FILTER_SELECT_SUCCEEDED,
  ON_LENS_FILTER_SELECT_FAILED,
} from './constants';

const initialState = fromJS({
  leftStripAnimStates: LEFT_STRIP_ANIM_STATES,
  leftStripAnimState: LEFT_STRIP_ANIM_STATES.EXPANDED,
  searchResults: [],
  filteredSearchResults: [],
  viewMode: VIEW_MODES.HOME,
  loadingInProgress: false,
  isAccessRequestModalOpen: false,
  accessDashboardName: '',
});

function SearchResultsPageReducer(state = initialState, action) {
  switch (action.type) {
    case GET_ALL_DASHBOARDS_SUCCEEDED:
      return state.merge({
        'searchResults': fromJS(action.data.hits.hits),
        'filteredSearchResults': fromJS(action.data.hits.hits),
        });

      return state.set('searchResults', fromJS(action.data.hits.hits));
      break;

    case GET_ALL_DASHBOARDS_FAILED:
      console.error(action.message);  
      return state;
      break;

    case GET_DASHBOARD_SEARCH_RESULTS_SUCCEEDED:
      const results = action.data.hits.hits;
      const filters = getUnqiueFilters (results);
      return state.merge({
        'filterMenuList': fromJS(filters),
        'searchResults': fromJS(results),
        'filteredSearchResults': fromJS(results),
        'viewMode': VIEW_MODES.SEARCH_RESULTS
        });
      break;

    case GET_DASHBOARD_SEARCH_RESULTS_FAILED:
      console.error(action.message);  
      return state;
      break;

    case PUT_DASHBOARD_SEARCH_TEXT:
      return state.set('searchText', fromJS(action.searchText));
      return state;
      break;

    case ON_LEFT_STRIP_ADVANCE_ANIMATION:
      return state.set('leftStripAnimState', action.state.leftStripAnimState + 1);
      break;

    case ON_LEFT_STRIP_RETREAT_ANIMATION:
      return state.set('leftStripAnimState', action.state.leftStripAnimState - 1);
      break;

    case ON_VIEW_MODE_CHANGE:
      return state.merge({
        'viewMode': action.viewMode
      })
      break;

    case ON_VIEW_DASHBOARD:
      return state.merge({
        'currentDashboard': action.dashboard,
        'viewMode': VIEW_MODES.VIEW_DASHBOARD
      })
      break;

     case ON_ACCESS_REQUEST_OPEN:
      return state.merge({'isAccessRequestModalOpen': true, 'accessDashboardName': action.dashboardName});
      break;

     case ON_ACCESS_REQUEST_CLOSE:
      return state.set('isAccessRequestModalOpen', false);
      break;

    case ON_ACCESS_REQUEST_SUCCEEDED:
      return state.merge({
        isAccessRequestModalOpen: false,
        message: 'Your request has been submitted successfully.'
      })
      break;

    case ON_ACCESS_REQUEST_FAILED:
      console.error(action.message)
      return state.merge({
        isAccessRequestModalOpen: false, //true,
        message: action.message
      })
      break;

     case ON_LOADING_STATUS_CHANGE:
      return state.set('loadingInProgress', action.status);      
      break;

     case ON_LENS_FILTER_SELECT_SUCCEEDED:
      const _results = action.data.hits.hits;
      const _filters = getUnqiueFilters (_results);
      return state.merge({
        'filterMenuList': fromJS(_filters),
        'searchResults': fromJS(_results),
        'filteredSearchResults': fromJS(_results),
        'viewMode': VIEW_MODES.SEARCH_RESULTS
        });

      // return state.merge({
      //     'searchResults': fromJS(action.data.hits.hits),
      //     'filteredSearchResults': fromJS(action.data.hits.hits),
      //     'filterMenuList': fromJS({})
      //   });
      break;

     case ON_LENS_FILTER_SELECT_FAILED:
        console.error(action.message);  
      return state;
      break;

     case ON_MULTI_SELECT_CHANGE:
      // Evdrytime the dynamic filters (on the left strip) checked or unchecked the following 
      // code is executed. 
      // Logic - 
      // 1. Get the previous state of the filters data (before change)
      // 2. Get the item clicked - it can be either a section header or an item within the section
      // 3. Compute the new filter state based on the click event
      const filterList = state.get('filterMenuList').toJS();
      const filterItems = [...action.selectedItems.checkedItemsIndices]; // Convert Set into Array with ... spread operator

      const newFilterValues = filterList[action.sectionName].map( (f, index) => {
        return {...f, isChecked: filterItems.includes(index) }
      })
      filterList[action.sectionName] = newFilterValues;

      // Logic to update search results based on the filter clicked
      // 4. Get the previous search results (before change)
      // 5. Compute new Search results after applying the filters
      // 6. Save new filter values and search results in the store
      // Respective UI components will pick the latest values and refresh the screen
      const searchResults = state.get('searchResults').toJS();
      const newFilteredSearchResults = getUpdatedDashbaords(searchResults, filterList, action.sectionName);

      return state.merge({
        'filterMenuList': fromJS( filterList ),
        'filteredSearchResults': fromJS( newFilteredSearchResults ),
        'viewMode': VIEW_MODES.SEARCH_RESULTS
        });
      break;

    default:
      return state;
  }
}

function reduceFilters (results, attr) {
  // Accumulate filters values across dashboards and return the unique list of filter in the given section
  const accAttrs = 
    results.length > 1 ? 
    (results.reduce( (a,c) => {
        return [...(a['_source'] ? a['_source'][attr] : a), ...(c['_source'][attr])]
      }))
    : results[0] ? results[0]['_source'][attr]: [];

    const uAccAttrs = accAttrs.filter((x, i, a) => a.indexOf(x) === i);

    // Number of time filter appeared in dashbaords
    const list = uAccAttrs.map(x => 
      (
        {parent: attr, label: x, isChecked: false, count: accAttrs.filter(y => y === x).length}
      )
    )

    return list;
    // Get unque list of them
    //list.filter((x, i, a) => console.log(a, x, a.indexOf(x), i));

  // return uniqueAttr.map(x => ({parent: attr, label: x, isChecked: true}));
}

function getUnqiueFilters(results) {
  // Values must match with the attribute names in the metadata
  // All these attributes must be array elements even if there is just one item in the list
  // Order of these elements determine how they are shown on the UI in the left strip
  const includedSections = ['solutions', 'metrics', 'products']; 
  let uniqueFilters = {};

  // Iterate through each attribute and get unique values across the dashboard search results
  includedSections.forEach( x => {
    uniqueFilters[x] = reduceFilters(results, x);
  });

  return uniqueFilters;
}

Array.prototype.groupBy = function(prop) {
  return this.reduce(function(groups, item) {
    const val = item[prop]
    groups[val] = groups[val] || []
    groups[val].push(item)
    return groups
  }, {})
}

/**
 * Function to match dashboard results with the given filters
 * Consider the following sections and respective filters user can click within the sections
 * 1. Solutions - ["Revenue Cycle Management", "Consumer Payments"] 
 * 2. Metrics - ["Revenue", "Sales", "Transaction Volume"] 
 * 3. Tiers - [1, 2] 
 *
 * Requirements -
 * 1. Search should apply "OR" operator for filters within the section and "AND" operator across sections.
 */ 
function getUpdatedDashbaords(searchResults, filterList, changedSection) {
  // const filters = filterList[changedSection];
  let filteredDashboardList = searchResults;

  // const newFilteredResults = searchResults.filter( d => {
  //     return d['_source'][changedSection].some(r => {
  //       return (filterList[changedSection].find(f => f.label === r && f.isChecked )) 
  //     })
  //   }
  // );

  // filteredDashboardList = newFilteredResults;

  Object.entries(filterList).forEach(section => {
    let newFilteredResults = searchResults.filter( d => {
        return d['_source'][section[0]].some(r => {
          return (section[1].find(f => f.label === r && f.isChecked )) 
        }) 
      }
    );

    newFilteredResults = newFilteredResults.length === 0 ? searchResults: newFilteredResults;    
    const newList = filterOnlyCommonDashboards(filteredDashboardList, newFilteredResults)

    filteredDashboardList = [...newList];
  })

  return filteredDashboardList;
}

function applyLensFilter() {

}

function filterOnlyCommonDashboards(listA, listB) {
  return listA.filter( a => listB.filter( b => b["_source"].name === a["_source"].name ).length > 0 )
}

export default SearchResultsPageReducer;