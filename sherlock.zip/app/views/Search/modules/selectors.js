import { createSelector } from 'reselect';

const selectSearch = (state) => state.get('search');

const makeSelectViewMode = () => createSelector(
    selectSearch,
    (searchState) => {
        return searchState.get('viewMode');
    });

const makeSelectIsAccessRequestModalOpen = () => createSelector(
    selectSearch,
    (searchState) => {
        return searchState.get('isAccessRequestModalOpen');
    });

const makeSelectLoadingIndicator = () => createSelector(
    selectSearch,
    (searchState) => {
        return searchState.get('loadingInProgress');
    });

const makeSelectCurrentDashboard = () => createSelector(
    selectSearch,
    (searchState) => {
        return searchState.get('currentDashboard') ? searchState.get('currentDashboard').toJS() : {};
    });

const makeSelectFilterMenuList = () => createSelector(
    selectSearch,
    (searchState) => searchState.get('filterMenuList') ? searchState.get('filterMenuList').toJS() : {});

const makeSelectDashboards = () => createSelector(
  selectSearch,
  (searchState) => searchState.get('filteredSearchResults').toJS().map((dashboard) => {
    const data = ({
      title: dashboard["_source"].name,
      ...dashboard["_source"],
    });
    return data;
  }),
);

const makeSelectSearchText = () => createSelector(
  selectSearch,
  searchState => searchState.get('searchText')
);

const makeSelectLeftStrip = () => createSelector(
  selectSearch,
  (selectState) => ({
    leftStripAnimStates: selectState.get('leftStripAnimStates').toJS(),
    leftStripAnimState: selectState.get('leftStripAnimState'),
  })
);

const makeSelectAccessDashboardName = () => createSelector(
  selectSearch,
  searchState => searchState.get('accessDashboardName')
);

export {
  selectSearch,
  makeSelectLeftStrip,
  makeSelectDashboards,
  makeSelectSearchText,
  searchResults,
  makeSelectFilterMenuList,
  makeSelectViewMode,
  makeSelectCurrentDashboard,
  makeSelectLoadingIndicator,
  makeSelectIsAccessRequestModalOpen,
  makeSelectAccessDashboardName,
};
