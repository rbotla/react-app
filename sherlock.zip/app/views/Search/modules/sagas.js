import { call, put, takeLatest } from 'redux-saga/effects';
import Api from './api';
import {
  GET_ALL_DASHBOARDS_REQUESTED,
  GET_ALL_DASHBOARDS_SUCCEEDED,
  GET_ALL_DASHBOARDS_FAILED,
  GET_DASHBOARD_SEARCH_RESULTS_REQUESTED,
  GET_DASHBOARD_SEARCH_RESULTS_SUCCEEDED,
  GET_DASHBOARD_SEARCH_RESULTS_FAILED,
  PUT_DASHBOARD_SEARCH_TEXT,
  ON_VIEW_MODE_CHANGE,
  ON_VIEW_DASHBOARD,
  ON_LOADING_STATUS_CHANGE,
  VIEW_MODES,
  ON_ACCESS_REQUEST_SUBMIT,
  ON_ACCESS_REQUEST_SUCCEEDED,
  ON_ACCESS_REQUEST_FAILED,
  ON_LENS_FILTER_SELECT,
  ON_LENS_FILTER_SELECT_SUCCEEDED,
  ON_LENS_FILTER_SELECT_FAILED,
} from './constants';

// worker Saga: will be fired on GET_ALL_DASHBOARDS_REQUESTED actions
function* getAllDashboards(action) {
  try {
    const data = yield call(Api.getAllDashboards);
    yield put({ type: ON_LOADING_STATUS_CHANGE, status: true });
    yield put({ type: GET_ALL_DASHBOARDS_SUCCEEDED, data });
    yield put({ type: ON_LOADING_STATUS_CHANGE, status: false });
  } catch (e) {
    yield put({ type: GET_ALL_DASHBOARDS_FAILED, message: e.message });
    yield put({ type: ON_LOADING_STATUS_CHANGE, status: false });
  }
}

function sleep(ms) {
  return new Promise((resolve) =>
    setTimeout(resolve, ms)
  );
}

function* searchDashboards(action) {
  try {
    yield put({type: PUT_DASHBOARD_SEARCH_TEXT, searchText: action.searchText});
    yield put({ type: ON_LOADING_STATUS_CHANGE, status: true });
    yield put({ type: ON_VIEW_MODE_CHANGE, viewMode: VIEW_MODES.SEARCH_RESULTS });
    //yield sleep(3000);
    const data = yield call(Api.searchAll, action.searchText);
    yield put({ type: GET_DASHBOARD_SEARCH_RESULTS_SUCCEEDED, data });
    yield put({ type: ON_LOADING_STATUS_CHANGE, status: false });
  } catch (e) {
    yield put({ type: GET_DASHBOARD_SEARCH_RESULTS_FAILED, message: e.message });
    yield put({ type: ON_LOADING_STATUS_CHANGE, status: false });
  }
}

function* submitAccessRequest(action) {
  try {
    const data = yield call(Api.saveNewRequest, action.data);
    yield put({ type: ON_ACCESS_REQUEST_SUCCEEDED });
  } catch (e) {
    yield put({ type: ON_ACCESS_REQUEST_FAILED, message: e.message });
  }
}

function* searchDashboardsByLens(action) {
  try {
    yield put({type: PUT_DASHBOARD_SEARCH_TEXT, searchText: action.item.name + " Lens"});
    yield put({type: ON_LOADING_STATUS_CHANGE, status: true });
    yield put({type: ON_VIEW_MODE_CHANGE, viewMode: VIEW_MODES.SEARCH_RESULTS });
    //yield sleep(3000);
    const data = yield call(Api.searchByLens, action.item.name, action.item.lens, action.item.ring1, action.item.ring2, action.item.ring3);
    yield put({ type: ON_LENS_FILTER_SELECT_SUCCEEDED, data });
    yield put({ type: ON_LOADING_STATUS_CHANGE, status: false });
  } catch (e) {
    yield put({ type: ON_LENS_FILTER_SELECT_FAILED, message: e.message });
    yield put({ type: ON_LOADING_STATUS_CHANGE, status: false });
  }
}

function* rootSaga() {
  yield takeLatest(GET_ALL_DASHBOARDS_REQUESTED, getAllDashboards);
  yield takeLatest(GET_DASHBOARD_SEARCH_RESULTS_REQUESTED, searchDashboards);
  yield takeLatest(ON_ACCESS_REQUEST_SUBMIT, submitAccessRequest);
  yield takeLatest(ON_LENS_FILTER_SELECT, searchDashboardsByLens);
}

export default [
  rootSaga
];
