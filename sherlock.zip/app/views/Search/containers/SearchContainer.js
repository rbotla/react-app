import { connect } from 'react-redux';
import Search from '../components/Search.jsx';
import { 
	onDashboardSearch, 
	getAllDashboards, 
  onAdvanceLeftStripAnimation,
  onRetreatLeftStripAnimation,
  onViewModeChange,
  onViewDashboard,
  onMultiSelectChange,
  onAccessRequestModalClose,
  onAccessRequestSubmit,
  onAccessRequestModalOpen,
  onFilterByLens,
} from '../modules/actions';
import { 
  makeSelectLeftStrip, 
  makeSelectDashboards, 
  makeSelectSearchText,
  makeSelectFilterMenuList,
  makeSelectViewMode,
  makeSelectCurrentDashboard,
  makeSelectLoadingIndicator,
  makeSelectIsAccessRequestModalOpen,
  makeSelectAccessDashboardName,
} from '../modules/selectors';

const mapDispatchToProps = dispatch => ({
	onDashboardSearch: searchText => dispatch(onDashboardSearch(searchText)),
  onLoadGetAllDashboards: () => dispatch(getAllDashboards()),
  onViewModeChange: (viewMode) => dispatch(onViewModeChange(viewMode)),
	onViewDashboard: (dashboard) => dispatch(onViewDashboard(dashboard)),
  uiActions: {
    onLeftStripExpandCollapse: (e, state) => {
      state.leftStripAnimState === state.leftStripAnimStates.EXPANDED
      ? dispatch(onAdvanceLeftStripAnimation(state))
      : dispatch(onRetreatLeftStripAnimation(state));
    },
  },
  leftStripActions: {
    onAdvanceAnimation: (e, state) => dispatch(onAdvanceLeftStripAnimation(state)),
    onRetreatAnimation: (e, state) => dispatch(onRetreatLeftStripAnimation(state)),
    onFilterByLens: (item) => dispatch(onFilterByLens(item)),
    onMultiSelectChange: (isSectionHeader, sectionName, changedItems) => 
                dispatch(onMultiSelectChange(isSectionHeader, sectionName, changedItems)),
  },
  accessRequestActions : {
    onAccessRequestModalClose: () => dispatch(onAccessRequestModalClose()),
    onAccessRequestSubmit: (data) => dispatch(onAccessRequestSubmit(data)),
    onAccessRequestModalOpen: (dashboardName) => dispatch(onAccessRequestModalOpen(dashboardName))
  },
});

const mapStateToProps = (state) => {
  const leftStripConfig = makeSelectLeftStrip()(state);
  const dashboards = makeSelectDashboards()(state);
  const searchText = makeSelectSearchText()(state);
  const filterMenuList = makeSelectFilterMenuList()(state);
  const viewMode = makeSelectViewMode()(state);
  const currentDashboard = makeSelectCurrentDashboard()(state);
  const loadingIndicator = makeSelectLoadingIndicator()(state);
  const isAccessRequestModalOpen = makeSelectIsAccessRequestModalOpen()(state);
  const accessDashboardName = makeSelectAccessDashboardName()(state);
	return ({
		 ...state,
		 leftStripConfig,
		 dashboards,
     searchText,
     filterMenuList,
     viewMode,
     currentDashboard,
     loadingIndicator,
     isAccessRequestModalOpen,
     accessDashboardName,
		})
}

export default connect(mapStateToProps, mapDispatchToProps)(Search);
