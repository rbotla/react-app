import SearchContainer from './containers/SearchContainer';

export default SearchContainer;
