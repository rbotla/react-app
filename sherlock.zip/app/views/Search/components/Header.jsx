import React from 'react';
import PropTypes from 'prop-types';
import { DetailHeader } from 'ui-core';

import HeaderWrapper from '../styledComponents/HeaderWrapper';

const Header = (props) => {
  return (
    <HeaderWrapper>
      <DetailHeader
        buttonTooltipPosition="left-center"
        amountKey="number"
        buttonType={props.buttonType}
        inlineClass={props.isHidden ? 'hidden' : ''}
        onButtonClick={props.onButtonClick}
        count={props.count}
        marginBottom={12}
        title={props.title}
      />
    </HeaderWrapper>
  );
};

Header.defaultProps = {
  title: null,
  amountKey: null,
  className: null,
};

Header.propTypes = {
  onButtonClick: PropTypes.func,
  count: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  isHidden: PropTypes.bool,
  buttonType: PropTypes.oneOf(['collapse', 'expand', 'close']),
  userCount: PropTypes.number,
  title: PropTypes.string,
};

export default Header;
