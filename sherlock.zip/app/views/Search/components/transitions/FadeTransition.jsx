import React from 'react';
import PropTypes from 'prop-types';
import { Transition } from 'react-transition-group';

import { LEFT_STRIP_FADE } from '../../../commonResources/constants/timings';

const duration = LEFT_STRIP_FADE;

const defaultStyle = {
  transition: `opacity ${duration}ms ease-in-out`,
  opacity: 0,
};

const transitionStyles = {
  entering: { opacity: 1 },
  entered: { opacity: 1 },
};

const FadeTransition = (props) => {
  return (
    <Transition
      in={props.in}
      timeout={props.timeout || duration}
      onEntered={props.onEntered}
      onExited={props.onExited}
    >
      { state => (
        <div
          style={{
            ...defaultStyle,
            ...transitionStyles[state],
          }}
          className={`${props.className} ${state}`}
        >
          {props.children}
        </div>
      )}
    </Transition>
  );
};

FadeTransition.defaultProps = {
  onExited: () => false,
  onEntered: () => false,
  timeout: 0,
  className: '',
};

FadeTransition.propTypes = {
  in: PropTypes.bool.isRequired,
  children: PropTypes.node.isRequired,
  onExited: PropTypes.func.isRequired,
  onEntered: PropTypes.func.isRequired,
  timeout: PropTypes.oneOfType([
    PropTypes.object,
    PropTypes.number,
  ]),
  className: PropTypes.string,
};

export default FadeTransition;
/* eslint-enable */
