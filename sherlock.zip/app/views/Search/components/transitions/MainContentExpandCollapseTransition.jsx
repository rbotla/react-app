import React from 'react';
import PropTypes from 'prop-types';
import { Transition } from 'react-transition-group';

import MainContentWrapper from '../../styledComponents/MainContentWrapper';
import { DETAIL_PANE_EXPAND_COLLAPSE, LEFT_STRIP_EXPAND_COLLAPSE } from '../../../commonResources/constants/timings';

const widthDuration = DETAIL_PANE_EXPAND_COLLAPSE;
const paddingDuration = LEFT_STRIP_EXPAND_COLLAPSE;

const defaultStyle = {
  transition: `width ${widthDuration}ms ease-in-out, padding ${paddingDuration}ms ease-in-out`,
  width: '100%',
  overflowX: 'hidden',
};

const transitionStyles = {
  entering: { width: '50%' },
  entered: { width: '50%' },
};

const MainContentExpandCollapseTransition = (props) => {
  return (
    <Transition
      in={props.in}
      timeout={widthDuration}
      appear
    >
      { state => (
        <MainContentWrapper
          style={{
            ...defaultStyle,
            ...transitionStyles[state],
          }}
          className={state}
          leftStripPadding={props.leftStripPadding}
        >
          {props.children}
        </MainContentWrapper>
      )}
    </Transition>
  );
};


MainContentExpandCollapseTransition.propTypes = {
  in: PropTypes.bool.isRequired,
  children: PropTypes.node.isRequired,
  leftStripPadding: PropTypes.number.isRequired,
};

export default MainContentExpandCollapseTransition;
