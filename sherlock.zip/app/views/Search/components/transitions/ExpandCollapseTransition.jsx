import React from 'react';
import PropTypes from 'prop-types';
import { Transition } from 'react-transition-group';

import DetailPaneWrapper from '../../styledComponents/DetailPaneWrapper';

import { DETAIL_PANE_EXPAND_COLLAPSE } from '../../../commonResources/constants/timings';
const duration = DETAIL_PANE_EXPAND_COLLAPSE;

const defaultStyle = {
  transition: `width ${duration}ms ease-in-out`,
  width: '0',
  overflowX: 'hidden',
};

const transitionStyles = {
  entering: { width: '50%' },
  entered: { width: '50%' },
};

const ExpandCollapseTransition = (props) => {
  return (
    <Transition
      in={props.in}
      timeout={duration}
      onEntered={props.onEntered}
      onExited={props.onExited}
      appear
    >
      { state => (
        <DetailPaneWrapper
          style={{
            ...defaultStyle,
            ...transitionStyles[state],
          }}
          className={state}
          leftStripPadding={props.leftStripPadding}
        >
          {props.children}
        </DetailPaneWrapper>
      )}
    </Transition>
  );
};


ExpandCollapseTransition.propTypes = {
  in: PropTypes.bool.isRequired,
  children: PropTypes.node.isRequired,
  onEntered: PropTypes.func.isRequired,
  onExited: PropTypes.func.isRequired,
  leftStripPadding: PropTypes.number.isRequired,
};

export default ExpandCollapseTransition;
