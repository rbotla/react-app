import React from 'react';
import PropTypes from 'prop-types';
import { browserHistory } from 'react-router';
import CardContentSectionTitle from '../../styledComponents/CardContentSectionTitle.jsx';
import CardContentSectionDetails from '../../styledComponents/CardContentSectionDetails.jsx';
import ViewDashboardWrapper from '../../styledComponents/ViewDashboardWrapper.jsx';
import ViewDashboardImageWrapper from '../../styledComponents/ViewDashboardImageWrapper.jsx';
import DashboardImage from '../../styledComponents/DashboardImage.jsx';
import styled from 'styled-components';
import Header from '../Header';
import {VIEW_MODES} from '../../modules/constants';
import {S3_DB_IMAGE_PREFIX} from '../../../../constants/app.js';
import ButtonGroup from '../../styledComponents/ButtonGroup';
import { Button } from 'ui-core';

const Divider = styled.div`
  padding: .3em 0;
`;

const handleViewDashboardClick = (dashboardUrl) => {
  window.open(dashboardUrl, '_blank');
}

const handleAccessDashboardClick = (onAccessRequestModalOpen, dashboardName) => {
  onAccessRequestModalOpen(dashboardName);
}

export class DashboardDetails extends React.Component {
	constructor(props) {
		super(props);
	}

	render () {
		const dashboard = this.props.dashboard;
		return (
      <div>
      <Header
        title= {dashboard.title} 
        onButtonClick={(e) => this.props.onViewModeChange(VIEW_MODES.SEARCH_RESULTS)}
        isHidden={false}
        buttonType={'close'}
      />
      <ButtonGroup>
        <Button
          buttonType="emphasized"
          size="medium"
          name="Open Dashboard"
          onClick={(e, f) => handleViewDashboardClick(dashboard.url)}
        />
        <Button
          buttonType="standard"
          size="medium"
          name="Request Access"
          onClick={(e, f) => handleAccessDashboardClick(this.props.onAccessRequestModalOpen, dashboard.title)}
        />
      </ButtonGroup>
			<ViewDashboardWrapper>
        <div style={{display: "flex", flexDirection: "row", justifyContent: "space-between"}}>
          <div style={{flex: "0 0 50%"}}>
            <ViewDashboardImageWrapper>
    	        <DashboardImage src={S3_DB_IMAGE_PREFIX+dashboard.imageURL} width="450px"/>
    	      </ViewDashboardImageWrapper>
          </div>
          <div style={{flex: "0 0 50%", margin: "0 1.5rem 10px 30px", wordBreak: "break-all", wordWrap: "break-word"}}>
            <Divider />
            <CardContentSectionTitle>Business Unit </CardContentSectionTitle>
            <CardContentSectionDetails>{dashboard['Parent-Business-Unit']}</CardContentSectionDetails>
            <Divider />
            <CardContentSectionTitle>Solution</CardContentSectionTitle>
            <CardContentSectionDetails>{dashboard.solutions.join(',')}</CardContentSectionDetails>
            <Divider />
            <CardContentSectionTitle>Tier - {dashboard.tier.join(',')}</CardContentSectionTitle>
            <Divider />
            <CardContentSectionTitle> Metrics </CardContentSectionTitle>
            <CardContentSectionDetails>{dashboard.metrics.join(", ")}</CardContentSectionDetails>
            <Divider />
            {
            dashboard.products.size > 0 ? 
              <div>
        	      <CardContentSectionTitle> Products </CardContentSectionTitle>
                <CardContentSectionDetails>{dashboard.products.join(", ")}</CardContentSectionDetails>
              </div>
            	: 
              null
             }
            <Divider />
    	      <CardContentSectionTitle> Filters </CardContentSectionTitle>
            {
            dashboard.filters ? 
              <CardContentSectionDetails>{dashboard.filters.join(", ")}</CardContentSectionDetails>
            : 'Not Available'
            }
            <Divider />
          </div>
        </div>
            <Divider />
			</ViewDashboardWrapper>
      </div>
		)
	}
}

DashboardDetails.defaultProps = {
};

DashboardDetails.propTypes = {
  dashboard: PropTypes.object,
  onViewModeChange: PropTypes.func,
  onAccessRequestModalOpen: PropTypes.func,
};

export default DashboardDetails;
