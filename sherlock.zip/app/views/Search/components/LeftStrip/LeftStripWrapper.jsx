import React from 'react';
import PropTypes from 'prop-types';
import { CardTitle, LeftStrip, MultiSelectGroup, SingleSelectSection, SingleSelectGroup } from 'ui-core';
import LeftStripInput from './LeftStripInput';
import {VIEW_MODES} from '../../modules/constants';

const  handleMenuItemGeneration = (list) => {
  return list.length > 0 ? list.map((item, index) => (
    {
      id: item.parent + "|" + item.label, //.replace(new RegExp(" ", "g"), '-')+index+'_id2',
      key: "key-" + item.parent + "|" + item.label,
      text: item.label,
      count: item.count,
      tooltipText: 'Dashboards',
      tooltipWidth: 100,
      isLensExpanded: false,
      isChecked: item.isChecked
    }
  )) : [];
}

class LeftStripWrapper extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      lensMenu: {
        expandedSections: new Set(),
        isExpanded: true,
        selectedIndex: null,
        selectedSection: null
      }
    };
    this.renderLensMenuList = this.renderLensMenuList.bind(this);
    this.onMultiItemCheck = this.onMultiItemCheck.bind(this);
    this.onMulGroupCheck = this.onMulGroupCheck.bind(this);
    this.computeCheckedItems = this.computeCheckedItems.bind(this);
    this.onSingleSelect = this.onSingleSelect.bind(this);
  }
  onMultiItemCheck = (e,f) => {
    // console.log(false, e.target.name.split('|')[0], f);
    this.props.leftStripActions.onMultiSelectChange(false, e.target.name.split('|')[0], f)
  };
  onMulGroupCheck = (e,f) => {return;}; //this.props.leftStripActions.onMultiSelectChange(true, e.target.name, f)
  computeCheckedItems (sectionNum, itemList) {
    const list = itemList.map( (x, index) => x.isChecked ? sectionNum + "|" + index : null)
    return list;
  }

  onSingleSelect(event, state, isSectionHeaderClicked) {
    this.setState({lensMenu: state});
    if (!isSectionHeaderClicked) {
      const secIndex = state.selectedSection == null ? 1 : state.selectedSection;
      const itemIndex = state.selectedSection == null ? state.selectedIndex - 1 : state.selectedIndex;
      const options = [
          [
            {name: 'Medical Network', lens: 'organization', ring1: 'Organization', ring2: 'Network Solutions', ring3: 'Medical'}, 
            {name: 'B2B Payments', lens: 'organization', ring1: 'Organization', ring2: 'Network Solutions', ring3: 'B2B'}, 
            {name: 'C2B Payments', lens: 'organization', ring1: 'Organization', ring2: 'Network Solutions', ring3: 'C2B'}, 
            {name: 'Clinincal Network', lens: 'organization', ring1: 'Organization', ring2: 'Network Solutions', ring3: 'Clinincal'}, 
            {name: 'RCM', lens: 'organization', ring1: 'Organization', ring2: 'S&A', ring3: 'RCM'}, 
            {name: 'Decision Analytics', lens: 'organization', ring1: 'Organization', ring2: 'S&A', ring3: 'Decision Analytics'}, 
            {name: 'Print (CPS)', lens: 'organization', ring1: 'Organization', ring2: 'TES', ring3: 'Print (CPS)'}, 
            {name: 'Infosec', lens: 'organization', ring1: 'Organization', ring2: 'R&D IT', ring3: 'Infosec'}, 
            {name: 'ETPM', lens: 'organization', ring1: 'Organization', ring2: 'R&D IT', ring3: 'ETPM'}, 
            {name: 'Pricing', lens: 'organization', ring1: 'Organization', ring2: 'Finance', ring3: 'Pricing'}
            ], 
          [
            {name: 'Product', lens: 'product'},
            {name: 'Customer', lens: 'customer'}, 
            {name: 'Spend', lens: 'spend'}, 
            {name: 'Revenue', lens: 'revenue'}, 
            {name: 'Sales', lens: 'sales'}, 
            {name: 'Qual', lens: 'qualitative'}
            ]
        ];
      // Call onFilterByLens api
      this.props.leftStripActions.onFilterByLens(options[secIndex][itemIndex]);
    }
  }

  renderLens2MenuList = () => {
    <SingleSelectGroup
      items={
        [{
          title: 'Section 1',
          data: ['Section 1 Option 1', 'Section 1 Option 2', 'Section 1 Option 3'],
        }, {
          title: 'Section 2',
          data: ['Section 2 Option 1', 'Section 2 Option 2', 'Section 2 Option 3'],
        }, 'Item 3', 'Item 4']
      }
      title='example title'
      groupTitle='Expand Group'
      orientation='right'
      onOpen={() => false}
      onSelect={() => false}
      domID="test-id"
    />
  }

  onSingleSelectOpen(e, state) {
    this.setState({lensMenu: state});
  }

  renderLensMenuList = () => (
    <SingleSelectGroup
      items={
        [
          {
            title: 'Organizations',
            domID: 'org-menu-id',
            data: [
              {text: 'Medical Network', count: 28, tooltipText: 'dashboards'}, 
              {text: 'B2B Payments', count: 5, tooltipText: 'dashboards'}, 
              {text: 'C2B Payments', count: 20, tooltipText: 'dashboards'}, 
              {text: 'Clinincal Network', count: 1, tooltipText: 'dashboards'}, 
              {text: 'RCM', count: 6, tooltipText: 'dashboards'}, 
              {text: 'Decision Analytics', count: 3, tooltipText: 'dashboards'}, 
              {text: 'Print (CPS)', count: 12, tooltipText: 'dashboards'}, 
              {text: 'Infosec', count: 9, tooltipText: 'dashboards'}, 
              {text: 'ETPM', count: 9, tooltipText: 'dashboards'}, 
              {text: 'Pricing', count: 2, tooltipText: 'dashboards'}, 
            ],
          },
          {text: 'Product', count: 76, tooltipText: 'dashboards'}, 
          {text: 'Customer', count: 49, tooltipText: 'dashboards'}, 
          {text: 'Spend', count: 9, tooltipText: 'dashboards'}, 
          {text: 'Revenue', count: 19, tooltipText: 'dashboards'}, 
          {text: 'Sales', count: 3, tooltipText: 'dashboards'}, 
          {text: 'Qualitative', count: 2, tooltipText: 'dashboards'}, 
        ] 
      }
      title='Lenses'
      groupTitle='Expand Group'
      orientation='right'
      onSectionExpand={(e,state) => this.onSingleSelect(e,state, true)}
      onSelect={(e,state) => this.onSingleSelect(e,state, false)}
      onOpen={(e, state) => { this.onSingleSelectOpen(e, state); }}
      deferState={this.state.lensMenu}
      domID="lens-menu-group-id"
    />
  )

  render () {
    return (
          <LeftStrip
            title=""
            domID="left_strip"
            animStates={this.props.leftStripConfig.leftStripAnimStates}
            animState={this.props.leftStripConfig.leftStripAnimState}
            advanceAnimation={(e) => this.props.leftStripActions.onAdvanceAnimation(e, this.props.leftStripConfig)}
            retreatAnimation={(e) => this.props.leftStripActions.onRetreatAnimation(e, this.props.leftStripConfig)}
          >
            <div style={{display: "flex", flexDirection: "row", alignItems: "center", justifyContent: "space-around"}}>
              <div style={{marginBottom: "20px", textAlign: "center"}}>
                <img src="https://s3.amazonaws.com/edw-chc-prod-datasolutions/sherlock-web-app/images/Sherlock_1.png" />
              </div>
              <LeftStripInput
                onEnterPress={() => false}
                onButtonClick={() => false}
                placeholder="Search"
                buttonContent={'button'}
                onSearchSubmit={this.props.onSearchSubmit}
              />
            </div>
            {
            this.props.viewMode === VIEW_MODES.SEARCH_RESULTS ? 
              <div  style={{marginBottom: "10px"}}>
                <CardTitle text={"Filters"} domID="filters-title"/>
              </div>
              : null
            }
            {
            this.props.viewMode === VIEW_MODES.HOME ? 
              this.renderLensMenuList()
            :
              this.props.filterMenuList ?
              Object.entries(this.props.filterMenuList).length > 0 ? 
                Object.entries(this.props.filterMenuList).map((item, index) => (
                  <MultiSelectGroup
                    headerId={item[0]}
                    key={index}
                    headerText={item[0]}
                    menuItems={handleMenuItemGeneration(item[1])}
                    onCheckItem={(e,f) => this.onMultiItemCheck(e, f)}
                    onToggleMenu={(e, f) => {
                      const obj = new Object();
                      obj[`${item[0]}.isOpen`] = f.isOpen;
                      this.setState(obj)
                    }}
                    onCheckGroup={(e,f) => this.onMulGroupCheck(e, f)}
                    /*
                    deferState={{
                        isHeaderChecked: this.state[`${item[0]}.isHeaderChecked`] || true,
                        isOpen: this.state[`${item[0]}.isOpen`] || false,
                        checkedItemsIndices: new Set(this.computeCheckedItems(index, item[1])),
                      }}
                    */
                  />
                ))
                : null
              : null
            }
          </LeftStrip>
    )
  }
};

LeftStripWrapper.propTypes = {
  leftStripConfig: PropTypes.object,
  leftStripActions: PropTypes.shape({
    onSingleGroupSelect: PropTypes.func,
    onSingleSectionOpenClose: PropTypes.func,
    onSingleSectionSelect: PropTypes.func,
    onMultiGroupCheck: PropTypes.func,
    onMultiGroupCheckHeader: PropTypes.func,
    onAdvanceAnimation: PropTypes.func,
    onRetreatAnimation: PropTypes.func,
    onMultiSelectChange: PropTypes.func,
    onFilterByLens: PropTypes.func,
  }),
  onSearchSubmit: PropTypes.func.isRequired,
  filterMenuList: PropTypes.object,
  viewMode: PropTypes.any,
};

export default LeftStripWrapper;
/* eslint-enable */



            // <div style={{display: "flex", flexDirection: "row", alignItems: "center", justifyContent: "space-around"}}>
            //   <div style={{marginBottom: "20px", textAlign: "center"}}>
            //     <img src="https://s3.amazonaws.com/edw-chc-prod-datasolutions/sherlock-web-app/images/Sherlock_1.png" />
            //   </div>

            //   <LeftStripInput
            //     onEnterPress={() => false}
            //     onButtonClick={() => false}
            //     placeholder="Search"
            //     buttonContent={'button'}
            //     onSearchSubmit={this.props.onSearchSubmit}
            //   />
            // </div>