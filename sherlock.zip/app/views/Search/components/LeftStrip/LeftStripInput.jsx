import React from 'react';
import { Input } from 'ui-core';
import PropTypes from 'prop-types';

import SearchInputWrapper from '../../styledComponents/SearchInputWrapper';
import SearchInputImage from '../../styledComponents/SearchInputImage';
//import searchIcon from '../../../../assets/search-icon-grey.png';
//import searchIcon from 'ui-core/images/search-icon-grey.png';

class LeftStripInput extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isFocused: false,
      searchText: '',
    };
    this.handleTextChange = this.handleTextChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleTextChange(event,data) {
    event.preventDefault();
    this.setState({
      searchText: data.value
    })
  }

  handleSubmit(e) {
    e.preventDefault();
    if (this.state.searchText === "") return;
    //console.log(val.value);
    this.props.onSearchSubmit(this.state.searchText);
  }

  render() {
    return (
      <SearchInputWrapper
        onBlur={() => this.setState({ isFocused: false })}
        onFocus={() => this.setState({ isFocused: true })}
      >
        <Input
          onEnterPress={this.handleSubmit}
          onButtonClick={this.handleSubmit} 
          onChange={this.handleTextChange}
          placeholder="Search"
          buttonContent={<SearchInputImage src={"https://s3.amazonaws.com/edw-chc-prod-datasolutions/sherlock-web-app/images/icons/search-icon-grey.png"} />}
          // buttonContent={this.state.isFocused
          //   ? 'Go'
          //   : 'Search'
          // }
        />
      </SearchInputWrapper>
    );
  }
}

LeftStripInput.propTypes = {
  onSearchSubmit: PropTypes.func.isRequired,
};

export default LeftStripInput;
