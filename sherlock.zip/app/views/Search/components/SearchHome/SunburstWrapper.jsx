import React from 'react';
import styled from 'styled-components';

const Container = styled.div`
  font-family: sans-serif;
  padding-top: 5px;
  margin: 0 auto; 
`;

const SunburstWrapper = ({ children, viewBox, width, height, focusOn }) => {
    return (
        <Container>
            <svg 
                viewBox={ viewBox } 
                preserveAspectRatio="xMidYMid meet" 
                width={width} 
                height={height}
                shapeRendering="geometricPrecision"
                onClick={() => focusOn()} // Reset zoom on canvas click
                >
                <g>
                  <image href="https://s3.amazonaws.com/botla/Sherlock.png" x="-30" y="-30"/>
                  { children }
                </g>
            </svg>  
        </Container>
    );
};

export default SunburstWrapper;

SunburstWrapper.defaultProps = {
  width: '100vw',
  height: 'calc(100vh - 100)',
  viewBox: ''
};