import React from 'react';
import PropTypes from 'prop-types';
import { browserHistory } from 'react-router';
import Sunburst from './Sunburst.jsx';
import data from './sunburst.json';

export class SearchHome extends React.Component {
	constructor(props) {
		super(props);
	}
	render () {
		return (
			<Sunburst onFilterByLens={this.props.onFilterByLens}/>
		)
	}
}

SearchHome.defaultProps = {

};

SearchHome.propTypes = {
  onFilterByLens: PropTypes.func
};

export default SearchHome;
