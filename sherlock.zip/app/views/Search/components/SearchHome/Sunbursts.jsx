import React from 'react';
import PropTypes from 'prop-types';
import { hierarchy, partition } from 'd3-hierarchy';
import { scaleOrdinal, schemeCategory10} from 'd3-scale';
import { path } from 'd3-path';
import { arc } from 'd3-shape';
import SunburstWrapper from './SunburstWrapper.jsx';
import Arc from './Arc.jsx';

import './Sunburst.scss';

export default class Sunburst extends React.Component {
  constructor(props) {
    super(props);

    this.width = window.innerWidth - 130,
    this.height = window.innerHeight - 130,
    this.radius = (Math.min(this.width, this.height) / 2) - 30;

    this.arcGenerator = arc()
        .startAngle(d => d.x0)
        .endAngle(d => d.x1)
        .innerRadius(d => Math.sqrt(d.y0))
        .outerRadius(d => Math.sqrt(d.y1))

    this.d3PartitionLayout = partition()
        .size([2 * Math.PI, this.radius * this.radius]);

    this.color = scaleOrdinal(this.props.colors || schemeCategory10);

    this.middleArcLine = d => {
        const halfPi = Math.PI/2;
        const angles = [x(d.x0) - halfPi, x(d.x1) - halfPi];
        const r = Math.max(0, (y(d.y0) + y(d.y1)) / 2);

        const middleAngle = (angles[1] + angles[0]) / 2;
        const invertDirection = middleAngle > 0 && middleAngle < Math.PI; // On lower quadrants write text ccw
        if (invertDirection) { angles.reverse(); }

        const path = d3.path();
        path.arc(0, 0, r, angles[0], angles[1], invertDirection);
        return path.toString();
    };

    this.textFits = d => {
        const CHAR_SPACE = 6;
        const deltaAngle = x(d.x1) - x(d.x0);
        const r = Math.max(0, (y(d.y0) + y(d.y1)) / 2);
        const perimeter = r * deltaAngle;

        return d.data.name.length * CHAR_SPACE < perimeter;
    };
  }

  componentWillMount() {
    this.setState({ selected: hierarchy(this.props.data) });
  }

  componentWillReceiveProps(nextProps) {
    this.setState({
      selected: hierarchy(nextProps.data)
    });
  }

  render() {
    return (
      <div style={{textAlign: "center", background: "white"}}>
        <img src="https://s3.amazonaws.com/botla/sunburst.jpeg" width="45%" />
      </div>
//      <SunburstWrapper viewBox={-this.radius + ' ' +  -this.radius + ' ' + ((this.radius * 2)) + ' ' + ((this.radius * 2))} >
 //       { this.renderArcs(this.transformToHierarchyData(this.state.selected).descendants()) }
   //   </SunburstWrapper>
    );
  }

  renderArcs(data) {
    return data.map((data, index) => {
        let style = {
            // fill: data.parent ? this.color((data.children ? data : data.parent).depth) : 'transparent'
            fill: data.parent ? this.color((data.children ? data : data.parent).depth) : 'transparent'
        };

        //TODO fix the unqiue key of the render
        return (
          <Arc key={ data.data[this.props.displayField] } onMouseOver={ () => { this.props.onMouseArcOver(data) } } 
              onMouseOut={ () => { this.props.onMouseArcOut(data) } } d={ this.arcGenerator(data) } style={ style }>
          </Arc>
        )
    });
  }

  toggleHover(data) {
    data.each((node) => { node.data.hoverOut = node.data.hover; node.data.hover = !node.data.hover; } );
    this.setState({ hover: data.data.hover });
  }

  transformToHierarchyData(data = []) {
    const hData = this.d3PartitionLayout(data.copy().sum((d) => { return d[this.props.valueField]; }));
 
    return hData;
  }
}

const emptyFn = () => {}

Sunburst.defaultProps = {
    displayField: '',
    valueField: 'value',
    onMouseArcOver: emptyFn,
    onMouseArcOut: emptyFn,
    radius: 100,
    colors: ['#008282', '#8400D9', '#EA40AC', '#46EAA7', '#FE6A43', '#4CC6FF'],
    data: {}
}

Sunburst.propTypes = {
  data: PropTypes.object.isRequired,
  displayField: PropTypes.string,
  valueField: PropTypes.string,
  onMouseArcOver: PropTypes.func,
  onMouseArcOut: PropTypes.func,
  radius: PropTypes.number,
  colors: PropTypes.array,
};
