import React, { Component } from 'react';
import { findDOMNode } from 'react-dom';
import SomeD3CustomComp from '../some-d3-custom-comp.js';

export default class SunburstRaw extends Component {

  componentDidMount() {
   this.injectD3Component();
  }

  componentDidUpdate() {
   this.injectD3Component();
  }

  injectD3Component() {
    const comp = findDOMNode(this.refs.nonReactContainer);
    const { data } = this.props;
    SomeD3CustomComp.render(comp, data);
  }

  render() {
    return <div ref="nonReactContainer"></div>
    );
  }
}