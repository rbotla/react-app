import React from 'react';
import styled from 'styled-components';
import PropTypes from 'prop-types';

const IframeWrapper = styled.div`
	width: 100%;
	height: calc(100vh - 30px);
`;

export default class Sunburst extends React.Component {
	
	constructor(props) {
		super(props);
		this.iframe = this.iframe.bind(this);
		this.handleFrameTasks = this.handleFrameTasks.bind(this);
	}

	iframe() {
    return {
      __html: this.props.iframe
    }
  }

	shouldComponentUpdate() {
	 return false;
	}

	componentDidMount() {
		window.addEventListener("message", this.handleFrameTasks);
	}
	componentWillUnmount() {
		window.removeEventListener("message", this.handleFrameTasks);
	}
	handleFrameTasks = (event) => {
		if (typeof event.data !== "string") return;

		const	data = event.data.split("#");

		let obj = {};

		if (data[0] === "lens") {
	    obj = {name: data[1], lens: data[1]} 			
		}
		else {
	    obj = {name: data[1], lens: 'organization', ring3: data[1]} 			
		}
    this.props.onFilterByLens(obj);
	}

	componentWillReceiveProps(nextProps) {

	}

	render () {
		return (
			<IframeWrapper>
			  <iframe id="iframe" src={this.props.iframeURL} scrolling="no"
			  	ref={(f) => this.ifr = f}
			  	style={{width: "100%", height: "100%", overflowY: "hidden", overflowX: "hidden"}} frameBorder="0"/>
			</IframeWrapper>
		)
	}
}

Sunburst.defaultProps = {
    // iframeURL: 'https://s3.amazonaws.com/edw-chc-prod-datasolutions/sherlock-web-app/js/sunburst-labels.html'
    iframeURL: 'http://localhost:9090/sunburst-labels.html'
}

Sunburst.propTypes = {
  iframeURL: PropTypes.string,
  onFilterByLens: PropTypes.func
};

