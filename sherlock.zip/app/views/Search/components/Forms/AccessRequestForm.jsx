import React from 'react';
import ReactDOM from 'react-dom';
import PropTypes from 'prop-types';
import {SectionTitle, Input, Button } from  'ui-core';
import InputTextArea from '../../../ui-core-ext/InputTextArea'; 
import Footer from '../../../styledComponents/RequestFormFooter.jsx';
import SupportFormWrapper from '../../../styledComponents/SupportFormWrapper.jsx';
import Space from '../../../styledComponents/Space.jsx';

export const DEFAULT_STATE = {
  email: '',
  requestDetails: '',
};

class AccessRequestForm extends React.Component {
  constructor(props) {
    super(props);
    this.state = DEFAULT_STATE;
    this.focusInput = this.focusInput.bind(this);
  }

  onEmailChange = (e) => {this.setState({ email: e.target.value })};
  onRequestDetailsChange = (e) => {this.setState({ requestDetails: e.target.value })};
  validate = () => {
  	return (this.state.email && this.state.requestDetails)
  };

  validateAndSubmit(e) {
    e.preventDefault();
    if (this.validate()) {
      this.props.onSubmit({
        email: this.state.email,
        dashboard: this.props.dashboardName,
        requestDetails: this.state.requestDetails,
        requestType: 'access'
      });
    }
    else {
    	console.error('Error validating the form');
    }
  }

  focusInput(component) {
	  if (component) {
	      ReactDOM.findDOMNode(component).focus(); 
	  }
  }

	render () {
		return (
			<SupportFormWrapper>
		    <SectionTitle
		      title={'Access request for - ' + this.props.dashboardName}
		      className="title"
		    />
	      <Input
          ref={this.focusInput} 
	        domID="email-input"
	        className="text-input"
	        label="EMAIL"
	        value={this.state.email}
	        onChange={e => this.onEmailChange(e)}
	      />
	      <InputTextArea
	        domID="request-details-input"
	        className="text-input"
	        label="Justification"
	        rows="200"
	        value={this.state.requestDetails}
	        onChange={e => this.onRequestDetailsChange(e)}
	      />
	      <Footer>
	        <Button
	          className="sign-in-cta"
	          name="Send"
	          size="medium"
	          buttonType="emphasized"
	          onClick={e => this.validateAndSubmit(e)}
	        />
	        <Space />
	        <Button
	          className="sign-in-cta"
	          name="Cancel"
	          size="medium"
	          buttonType="unstyled"
	          onClick={() => this.props.onCancel()}
	        />
	      </Footer>
		  </SupportFormWrapper>
	  )
	}
} 

AccessRequestForm.defaultProps = {
};

AccessRequestForm.propTypes = {
  onSubmit: PropTypes.func,
  onCancel: PropTypes.func,
  dashboardName: PropTypes.string,
};

export default AccessRequestForm;