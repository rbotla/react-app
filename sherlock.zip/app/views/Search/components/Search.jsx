import React from 'react';
import PropTypes from 'prop-types';

import '../styles.scss';
import '../uicl-work-arounds.scss';

import LeftStripWrapper from './LeftStrip/LeftStripWrapper';
import Header from './Header';
import MainContentExpandCollapseTransition from './transitions/MainContentExpandCollapseTransition';
import {Breadcrumb, LoadingIndicator} from 'ui-core';
import BreadcrumbsWrapper from '../styledComponents/BreadcrumbsWrapper.jsx';
import SearchResults from './SearchResults/SearchResults.jsx'
import { browserHistory } from 'react-router';
import DashboardDetails from './DashboardDetails/DashboardDetails.jsx';
import {VIEW_MODES} from '../modules/constants';
import SearchHome from './SearchHome/SearchHome.jsx';
import {Modal} from 'ui-core';
import AccessRequestForm from './Forms/AccessRequestForm.jsx';

const INITIAL_STATE = {
  dashboard_results: []
};

class Search extends React.Component {
  constructor(props) {
    super(props);
    this.state = INITIAL_STATE;
    this.handleBreadcrumbClick = this.handleBreadcrumbClick.bind(this);
    this.generateBreadCrumbs = this.generateBreadCrumbs.bind(this);
  }

  // componentWillMount() {
  //   this.props.onLoadGetAllDashboards();
  // }

  generateBreadCrumbs() {
    let breadCrumbs = undefined;
    if (this.props.viewMode === VIEW_MODES.HOME) {
      breadCrumbs = [{ title: 'Home' }];
    }
    else if (this.props.viewMode === VIEW_MODES.SEARCH_RESULTS) {
      breadCrumbs = [{ title: 'Home' }];
      breadCrumbs.push({ title: this.getSearchText(this.props.searchText), description: this.props.dashboards.length + ' dashboards' });
    }
    else if (this.props.viewMode === VIEW_MODES.VIEW_DASHBOARD){
      breadCrumbs = [{ title: 'Home'}];
      breadCrumbs.push({ title: this.getSearchText(this.props.searchText), description: this.props.dashboards.length + ' dashboards' });
      breadCrumbs.push({ title: this.props.currentDashboard.title});
    }
    return breadCrumbs;
  }
  
  handleBreadcrumbClick(e,f) {
    e.preventDefault();
console.log(e.target);
    switch (f){
      case "Home":
         browserHistory.push('/')
         this.props.onViewModeChange(VIEW_MODES.HOME);
         break;
      case "Search Results":
         browserHistory.push('/')
         this.props.onViewModeChange(VIEW_MODES.SEARCH_RESULTS);
         // trigger action to set the search results mode
         break;
      default:
         browserHistory.push('/')
    }
  }

  getSearchText(text) {
    console.log(text, text.replace(" Lens", ''));
    return text.indexOf("Lens") > -1 ? text.replace(" Lens", '') : "\"" + text + "\"";
  }
 
  render() {
    const leftStripConfig = this.props.leftStripConfig;
    const isExpanded = leftStripConfig.leftStripAnimState >= leftStripConfig.leftStripAnimStates.EXPAND_COLLAPSE;

    return (
      <div
        className={
          this.props.leftStripConfig.leftStripAnimState > this.props.leftStripConfig.leftStripAnimStates.FADE_CONTENT
            ? 'collapsed main-content'
            : 'expanded main-content'
        }
      >
        <LeftStripWrapper
          {...this.props}
          viewMode={this.props.viewMode}
          onSearchSubmit={this.props.onDashboardSearch}
          filterMenuList = {this.props.filterMenuList}
        />
        <MainContentExpandCollapseTransition
          leftStripPadding={0}
          in={false}
        >
          {
            (this.props.viewMode >= VIEW_MODES.HOME)? 
              <BreadcrumbsWrapper>
                <Breadcrumb
                  domID="test-id"
                  breadcrumbItems={this.generateBreadCrumbs()}
                  onBreadcrumbItemClick={(e,f) => this.handleBreadcrumbClick(e,f)}
                />
              </BreadcrumbsWrapper>
            : null
          }
          {
            this.props.isAccessRequestModalOpen ? 
            <Modal
              children={
                <AccessRequestForm 
                    onCancel={this.props.accessRequestActions.onAccessRequestModalClose}
                    onSubmit={this.props.accessRequestActions.onAccessRequestSubmit}
                    dashboardName={this.props.accessDashboardName}
                    />
              }
              domID="access-request-modal-id"
              onClickOut={() => this.props.accessRequestActions.onAccessRequestModalClose()}
              onModalToggle={() => this.props.accessRequestActions.onAccessRequestModalClose()}
              isOpen={true}
            />
            : null
          }

          {
            this.props.viewMode === VIEW_MODES.HOME ? 
              <SearchHome onFilterByLens={this.props.leftStripActions.onFilterByLens}/>
            :
            this.props.viewMode === VIEW_MODES.SEARCH_RESULTS ? 
              this.props.loadingIndicator ?
                <div>
                  <Header
                    title= {"Getting Results for "+ this.getSearchText(this.props.searchText)}
                    onButtonClick={e => browserHistory.push('/')}
                    isHidden={false}
                    buttonType={'close'}
                  />
                  <div style={{marginLeft: "30px"}}>
                    <LoadingIndicator domID="loading-id"/>
                  </div>
                </div>
              :
              this.props.dashboards.length > 0 ?
                <div>
                  <Header
                    title= {(this.props.searchText.indexOf("Lens") > -1 ? "" : "Results for ") + this.getSearchText(this.props.searchText)} 
                    //onButtonClick={e => this.props.uiActions.onLeftStripExpandCollapse(e, leftStripConfig)}
                    onButtonClick={e => this.props.onViewModeChange(VIEW_MODES.HOME)}
                    count={this.props.dashboards.length}
                    isHidden={false}
                    buttonType={'close'}
                    // buttonType={isExpanded ? 'collapse' : 'expand'}
                  />
                  <SearchResults 
                    dashboards={this.props.dashboards} 
                    onViewDashboard={this.props.onViewDashboard} 
                    {...this.props.accessRequestActions}
                    isAccessRequestModalOpen={this.props.isAccessRequestModalOpen}
                    onViewModeChange={this.props.onViewModeChange}
                    dashboardName={this.props.accessDashboardName}
                  />
                </div>
              :
                <Header
                  title= {"No results found for "+ this.getSearchText(this.props.searchText)} 
                  //onButtonClick={e => this.props.uiActions.onLeftStripExpandCollapse(e, leftStripConfig)}
                  onButtonClick={e => browserHistory.push('/')}
                  count={this.props.dashboards.length}
                  isHidden={false}
                  buttonType={'close'}
                  // buttonType={isExpanded ? 'collapse' : 'expand'}
                />
            :
              <DashboardDetails 
                    dashboard={this.props.currentDashboard} 
                    onViewModeChange={this.props.onViewModeChange}
                    {...this.props.accessRequestActions}
                    />
            }
        </MainContentExpandCollapseTransition>
      </div>
    );
  }
}

Search.defaultProps = {
  dashboards: [],
  searchText: "*",
  loadingIndicator: false,
};

Search.propTypes = {
  onDashboardSearch: PropTypes.func.isRequired,
  leftStripConfig: PropTypes.object,
  uiActions: PropTypes.objectOf(PropTypes.func),
  dashboards: PropTypes.array,
  searchText: PropTypes.string,
  filterMenuList: PropTypes.object,
  viewMode: PropTypes.any,
  onViewModeChange: PropTypes.func,
  currentDashboard: PropTypes.object,
  onViewDashboard: PropTypes.func,
  loadingIndicator: PropTypes.bool,
  accessRequestActions : PropTypes.object,
  isAccessRequestModalOpen: PropTypes.bool,
  accessDashboardName: PropTypes.string,
};

export default Search;
