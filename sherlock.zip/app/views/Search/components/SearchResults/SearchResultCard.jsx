import React from 'react';
import PropTypes from 'prop-types';
import { Card } from 'ui-core';
import CardContentWrapper from '../../styledComponents/CardContentWrapper.jsx';
import CardContent from '../../styledComponents/CardContent.jsx';
import CardContentImage from '../../styledComponents/CardContentImage.jsx';
import CardContentSectionTitle from '../../styledComponents/CardContentSectionTitle.jsx';
import CardContentSectionDetails from '../../styledComponents/CardContentSectionDetails.jsx';
import Thumbnail from '../../styledComponents/Thumbnail.jsx';
import '../../uicl-work-arounds.scss';
import {VIEW_MODES} from '../../modules/constants';
import {S3_DB_IMAGE_THUMBNAIL_PREFIX} from '../../../../constants/app.js';

const handleMenuClick = (e, f, onAccessRequestModalOpen, dashboardName, dashboardUrl) => {
  if (f.activeMenuItemIndex === 0) {
    window.open(dashboardUrl, '_blank');
  }
  else if (f.activeMenuItemIndex === 1) {
    onAccessRequestModalOpen(dashboardName);
  }
}
const trim = (text) => text.length > 30 ? text.substring(0, 30)+"..." : text;
const randomInage = () => images[Math.floor(Math.random() * images.length)]

export const SearchResultCard = (props) => {
  return(
  <Card
    domID={props.title}
    title={props.title}
    buttonType={"standard"}
    size={"small"}
    name={"View"}
    changeArrow={"cursor"}
    menuItems={[{ label: "Open Dashboard", id: "1" },{ label: "Request Access", id: "2" }]}
    onMenuClick={(e, f) => handleMenuClick(e,f, props.onAccessRequestModalOpen, props.title, props.url)}
    leftButtonClick={(e) => props.onViewDashboard(props)}
    /* Change the following to left: -125px */
    className="inline_buttonDropdown"
  >
    <CardContentWrapper>
      <Thumbnail src={S3_DB_IMAGE_THUMBNAIL_PREFIX+props.imageURL} />
      <CardContent>
        <CardContentSectionTitle>Solution</CardContentSectionTitle>
        <CardContentSectionDetails>{props.solutions.join(',')}</CardContentSectionDetails>
        <CardContentSectionTitle> Products </CardContentSectionTitle>
        {
        props.products ? 
          <CardContentSectionDetails>{trim(props.products.join(", "))}</CardContentSectionDetails>
        : <CardContentSectionDetails>'Not Available'</CardContentSectionDetails>
        }
        <CardContentSectionTitle> Metrics </CardContentSectionTitle>
        <CardContentSectionDetails>{trim(props.metrics.join(", "))}</CardContentSectionDetails>
      </CardContent>
    </CardContentWrapper>
  </Card>

)
}
SearchResultCard.defaultProps = {
  minLength: 10
};

SearchResultCard.propTypes = {
  title: PropTypes.string.isRequired,
  name: PropTypes.string.isRequired,
  ring1: PropTypes.string,
  ring2: PropTypes.string,
  ring3: PropTypes.string,
  tier: PropTypes.array,
  solution: PropTypes.array,
  parentBusinessUnit: PropTypes.string,
  url: PropTypes.string,
  imageURL: PropTypes.string,
  lens: PropTypes.array,
  showBookmark: PropTypes.bool,
  products: PropTypes.array,
  metrics: PropTypes.array,
  minLength: PropTypes.number,
  onViewDashboard: PropTypes.func,
  onAccessRequestModalOpen: PropTypes.func,
};

export default SearchResultCard;

const images = [
  'https://d85wutc1n854v.cloudfront.net/live/products/600x375/WB08N77TC.png',
  'https://www.klipfolio.com/sites/default/files/dashboard-examples-categories/shipping-status-dashboard.png',
  'https://d85wutc1n854v.cloudfront.net/live/products/600x375/WB07H3237.png'
]
