import React from 'react';
import PropTypes from 'prop-types';
import {DetailHeader, Breadcrumb} from 'ui-core';
import HeaderWrapper from '../../styledComponents/HeaderWrapper.jsx';
import CardsWrapper from '../../styledComponents/CardsWrapper.jsx';
import SearchResultCard from './SearchResultCard.jsx';
import BreadcrumbsWrapper from '../../styledComponents/BreadcrumbsWrapper.jsx';
import { browserHistory } from 'react-router';

export class SearchResults extends React.Component {
	constructor(props) {
		super(props);
		this.handleBreadcrumbClick = this.handleBreadcrumbClick.bind(this);
	}
	handleBreadcrumbClick(e,f) {
		e.preventDefault();
		f === "Sherlock Data Analytics" ? browserHistory.push('/') : null;
	}
	render () {
		return (
	    <CardsWrapper>
		  	{
		  		this.props.dashboards ? 
			  	this.props.dashboards.map((x, id) => (
		  			<SearchResultCard 
							  title={x.name}
							  key={'sr_'+id}
							  {...x}
								onViewDashboard={this.props.onViewDashboard}
								onAccessRequestModalOpen={this.props.onAccessRequestModalOpen}
			  		/>
			  	))
			  	: "No dashboards found for your search."
		  	}
		  </CardsWrapper>
		)
	}
}

SearchResults.defaultProps = {
};

SearchResults.propTypes = {
  dashboards: PropTypes.any.isRequired,
  searchText: PropTypes.string,
  onViewDashboard: PropTypes.func,
  isAccessRequestModalOpen: PropTypes.bool,
  onAccessRequestModalClose: PropTypes.func,
  onAccessRequestModalOpen: PropTypes.func,
  onAccessRequestSubmit: PropTypes.func,
  dashboardName: PropTypes.string,
};

export default SearchResults;
