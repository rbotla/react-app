import HomePageContainer from './containers/HomePageContainer';

export default HomePageContainer;
