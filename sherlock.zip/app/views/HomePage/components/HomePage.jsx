import React from 'react';
import BreadcrumbsWrapper from './BreadcrumbsWrapper.jsx';
import {Breadcrumb} from 'ui-core';

export const HomePage = (props) => (
  <div style={{backgroundColor: "#F9F9FB"}}>
  	<BreadcrumbsWrapper>
			<Breadcrumb
			  domID="test-id"
			  breadcrumbItems={[
			    { title: 'Sherlock Data Analytics', description: 'Home Page' },
			  ]}
			  onBreadcrumbItemClick={() => false}
			/>
		</BreadcrumbsWrapper>
	</div>
);

export default HomePage;
