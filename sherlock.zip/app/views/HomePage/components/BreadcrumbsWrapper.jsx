import styled from 'styled-components';

export default styled.div`
  padding: .5rem 0 1rem 0;
  border-bottom: solid 1px #C5C7CF;
`;
