import React from 'react';

export const SunBurnChart = (props) => {

	const diameter = 960,
    radius = diameter / 2,
    innerRadius = radius - 120;

	const cluster = d3.cluster()
	    .size([360, innerRadius]);

	const line = d3.radialLine()
	    .curve(d3.curveBundle.beta(0.85))
	    .radius(function(d) { return d.y; })
	    .angle(function(d) { return d.x / 180 * Math.PI; });

	let svg = d3.select("body").append("svg")
	    .attr("width", diameter)
	    .attr("height", diameter)
	  .append("g")
	    .attr("transform", "translate(" + radius + "," + radius + ")");

	const link = svg.append("g").selectAll(".link"),
	    node = svg.append("g").selectAll(".node");

		return (


			)
}


SunBurnChart.propTypes: {
  path:         React.PropTypes.string.isRequired
}


export default SunBurnChart;
