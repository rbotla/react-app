import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';

import Colors from '../colorVariables';
import Typography from '../typography';

export const CodeBackground = styled.div`
  background-color: ${Colors.darkestGrey};
  margin: 3em 2em;
  padding: 1em;
  max-width: 800px;
`;

export const CodeText = styled.pre`
  ${Typography.medium};
  font-family: "Lucida Console", Monaco, monospace;
  color: #F0E68C;
`;

const CodeExample = props => (
  <CodeBackground style={props.style}>
    <CodeText>
      {props.componentText}
    </CodeText>
  </CodeBackground>
);

CodeExample.defaultProps = {
  style: {},
};

CodeExample.propTypes = {
  componentText: PropTypes.string.isRequired,
  style: PropTypes.objectOf(PropTypes.string),
};

export default CodeExample;
