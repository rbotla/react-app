import styled from 'styled-components';
import Typography from '../typography';
import Colors from '../colorVariables';

export const GroupTitle = styled.div`
  color: ${Colors.secondary30};
  ${Typography.small};
  ${Typography.largeLineHeight};
  ${Typography.mediumBold};
  ${Typography.uppercase};
  ${Typography.LetterSpacing};
  margin-right: 0.2em;
`;

export default {
  GroupTitle,
};
