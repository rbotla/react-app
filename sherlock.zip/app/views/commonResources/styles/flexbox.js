import styled from 'styled-components';

export const BlockFlexParent = styled.div`
  display: -webkit-flex;
  display: flex;
`;

export const InlineFlexParent = styled.span`
  display: -webkit-inline-flex;
  display: inline-flex;
`;

export const FlexChild = styled.span`
  -webkit-flex: 1; /* Safari 6.1+ */
  -ms-flex: 1; /* IE 10 */
  flex: 1;
`;

export default {
  BlockFlexParent,
  InlineFlexParent,
  FlexChild,
};
