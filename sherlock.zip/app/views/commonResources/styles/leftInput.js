import styled from 'styled-components';

export const LeftInput = styled.input`
  margin-top: 0px;
  margin-right: 0.4rem;
  margin: 4px 0 0;
  line-height: normal;
  float: left;
`;

export const Wcheckbox = styled.div`
  display: flex;
  margin-top: 0px;
  margin-bottom: 0px;
  padding-left: 0px;
`;
export default {
  LeftInput,
  Wcheckbox,
};
