import styled from 'styled-components';
import { Colors } from '../colorVariables';
import Borders from '../borders';

export const BackgroundBlue = styled.span`
  display: inline-block;
  background: ${Colors.darkestSecondaryGrey};
`;

export const BackgroundGrey = styled.span`
  display: inline-block;
  background: ${Colors.faintestSecondaryGrey};
`;

export const BackgroundBlueGrey = styled.span`
  display: inline-block;
  background: ${Colors.blueGrey};
`;

export const BasicPadding = styled.span`
  display: inline-block;
  padding: 2em;
`;

export const PaddedDiv = styled.div`
  padding: 3em;
`;

export const Width200 = styled.span`
  display: inline-block;
  width: 200px;
`;

export const Width320 = styled.span`
  display: inline-block;
  width: 320px;
`;

export const Width400 = styled.span`
  display: inline-block;
  width: 400px;
`;

export const Width600 = styled.span`
  display: inline-block;
  width: 600px;
`;

export const Width800 = styled.span`
  display: inline-block;
  width: 800px;
`;

export const Width1000 = styled.span`
  display: inline-block;
  width: 1000px;
`;

export const Divider = styled.div`
  marginTop: '50px';
`;

export const LeftStripPadding = styled.div`
  paddingLeft: 18px;
  paddingRight: 18px;
`;

export const MastheadContainer = styled.div`
  height: 50px;
  background-color: ${Colors.darkestSecondaryGrey};
`;

export const CardContainer = styled.div`
  width: 300px;
  ${Borders.lighterGrey}
`;

export default {
  BackgroundBlue,
  BasicPadding,
  Width200,
  Width400,
  Width600,
  Width800,
  Width1000,
  Divider,
  LeftStripPadding,
  MastheadContainer,
  CardContainer,
};
