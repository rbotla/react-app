import styled from 'styled-components';
import Typography from '../typography';
import { Colors } from '../colorVariables';

export const UnstyledButton = styled.button`
  padding: 0;
  margin: 0;
  text-align: left;
  background: none;
  border: none;
  cursor: pointer;
  ${Typography.small};
  ${Typography.mediumBold};
  border-radius: 0;

  &.small {
    ${Typography.small};
  }

  &.medium {
    ${Typography.mediumLarge};
  }

  &.large {
    ${Typography.extraLarge};
  }

  &:disabled {
    cursor: default;
  }

  &.button, &.dropdown-button {
    outline: none;
  }

  &.unstyled, &.link {
    ${Typography.extraLargeLineHeight};
    padding: 0px 1em;

    &:focus:not(:active) {
      box-shadow: 0 0 0 1px ${Colors.defaultLight};
      border-radius: 2px;
    }
  }

  &.standard, &.primary, &.destroy {
    .dropdown-caret {
      fill: ${Colors.white};
    }
  }

  &.secondary, &.emphasized {
    .dropdown-caret {
      fill: ${Colors.darkestSecondaryGrey};
    }
  }

  &.deEmphasized {
    .dropdown-caret {
      fill: ${Colors.default};
    }
  }

  &.diminished {
    .dropdown-caret {
      fill: ${Colors.lightTurquoise};
    }
  }
`;

export const ButtonWithLinkStyling = styled(UnstyledButton) `
  font-size: inherit;
  text-transform: none;
  text-decoration: underline;
  text-decoration-color: ${Colors.lightGrey};
  color: ${Colors.darkerGrey};
  ${Typography.defaultFontWeight};

  &:hover {
    text-decoration-color: ${Colors.secondary30};
  }
`;

export const ButtonWithDefaultStyling = styled(UnstyledButton) `
  border-radius: 3px;
  padding: 0px 1em;
  max-width: 100%;
  display: inline-block;
  background-color: ${Colors.default};
  color: ${Colors.white};
  ${Typography.extraLargeLineHeight};
  ${Typography.uppercase};
  ${Typography.LetterSpacing};
  outline: none;
  border: 1px solid transparent;

  &.split_border_radius {
    border-top-right-radius: 0px;
    border-bottom-right-radius: 0px;
  }

  &:hover {
    background-color: ${Colors.darkGrey};
  }

  &:active {
    background-color: ${Colors.black};
  }

  &:focus:not(:active) {
    background-color: ${Colors.black};
    box-shadow: 0 0 0 1px ${Colors.white}, 0 0 0 2px ${Colors.black};
  }

  &:disabled {
    background-color: ${Colors.fainterGrey};
  }
`;

export const EmphasizedButton = styled(ButtonWithDefaultStyling) `
  background-color: ${Colors.primary};
  color: ${Colors.darkestSecondaryGrey};

  &:hover {
    background-color: ${Colors.primaryLight};
  }

  &:active {
    background-color: ${Colors.lightBlue};
  }

  &:focus:not(:active) {
    background-color: ${Colors.lightBlue};
    box-shadow: 0 0 0 1px ${Colors.white}, 0 0 0 2px ${Colors.lightBlue};
  }

  &:disabled {
    background-color: ${Colors.primaryLight};
    color: ${Colors.fadedGrey};

    .dropdown-caret {
      fill: ${Colors.fadedGrey};
    }
  }
`;

export const DeEmphasizedButton = styled(ButtonWithDefaultStyling) `
  background-color: transparent;
  color: ${Colors.default};
  border: 1px solid ${Colors.default};

  &:hover {
    background-color: transparent;
    border-color: ${Colors.secondary30};
    color: ${Colors.secondary30};

    .dropdown-caret {
      fill: ${Colors.secondary30};
    }
  }

  &:active {
    background-color: transparent;
    border-color: ${Colors.black};
    color: ${Colors.black};

    .dropdown-caret {
      fill: ${Colors.black};
    }
  }

  &:focus:not(:active) {
    border-color: ${Colors.default};
    color: ${Colors.default};
    background-color: ${Colors.white};
    box-shadow: 0 0 0 1px ${Colors.white}, 0 0 0 3px ${Colors.default};

    .dropdown-caret {
      fill: ${Colors.default};
    }
  }

  &:disabled {
    background-color: transparent;
    border-color: ${Colors.fainterGrey};
    color: ${Colors.fainterGrey};

    .dropdown-caret {
      fill: ${Colors.fainterGrey};
    }
  }
`;

export const DeEmphasizedReversedButton = styled(ButtonWithDefaultStyling) `
  background-color: transparent;
  color: ${Colors.white};
  border: 1px solid ${Colors.white};

  &:hover {
    background-color: transparent;
    border-color: ${Colors.primaryLight};
    color: ${Colors.primaryLight};

    .dropdown-caret {
      fill: ${Colors.primaryLight};
    }
  }

  &:active {
    background-color: transparent;
    border-color: ${Colors.lightBlue};
    color: ${Colors.lightBlue};

    .dropdown-caret {
      fill: ${Colors.lightBlue};
    }
  }

  &:focus:not(:active) {
    border-color: transparent;
    color: ${Colors.white};
    background-color: transparent;
    box-shadow: inset 0 0 0 1px ${Colors.white}, 0 0 0 2px ${Colors.white};

    .dropdown-caret {
      fill: ${Colors.white};
    }
  }

  &:disabled {
    background-color: transparent;
    border-color: ${Colors.turquoise};
    color: ${Colors.turquoise};

    .dropdown-caret {
      fill: ${Colors.turquoise};
    }
  }
`;

export const DiminishedButton = styled(ButtonWithDefaultStyling) `
  background-color: transparent;
  color: ${Colors.lightTurquoise};
  border: 1px solid transparent;

  &:hover {
    background-color: transparent;
    color: ${Colors.babyBlue};

    .dropdown-caret {
      fill: ${Colors.babyBlue};
    }
  }

  &:active {
    background-color: transparent;
    color: ${Colors.darkTurquoise};
    border: 1px solid transparent;
    box-shadow: none;

    .dropdown-caret {
      fill: ${Colors.darkTurquoise};
    }
  }

  &:focus:not(:active) {
    background-color: transparent;
    color: ${Colors.lightTurquoise};
    border: 1px solid ${Colors.lightTurquoise};
    box-shadow: 0 0 0 1px ${Colors.lightTurquoise};

    .dropdown-caret {
      fill: ${Colors.lightTurquoise};
    }
  }

  &:disabled {
    background-color: transparent;
    color: ${Colors.veryFaintGrey};

    .dropdown-caret {
      fill: ${Colors.veryFaintGrey};
    }
  }
`;


export const DestroyButton = styled(ButtonWithDefaultStyling) `
  background-color: ${Colors.negative};
  color: ${Colors.white};

  &:hover {
    background-color: ${Colors.destroyLight};
  }

  &:active {
    background-color: ${Colors.destroyDark};
  }

  &:focus:not(:active) {
    background-color: ${Colors.destroyDark};
    box-shadow: 0 0 0 1px ${Colors.white}, 0 0 0 2px ${Colors.negative};
  }

  &:disabled {
    background-color: ${Colors.negativeHighlight};
  }
`;

export default {
  UnstyledButton,
  ButtonWithLinkStyling,
  ButtonWithDefaultStyling,
  EmphasizedButton,
  DeEmphasizedButton,
  DeEmphasizedReversedButton,
  DestroyButton,
  DiminishedButton,
};
