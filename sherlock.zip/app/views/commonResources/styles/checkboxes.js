import styled from 'styled-components';
// import Typography from '../typography';
// import { Colors } from '../colorVariables';

export const WithTopOffset = styled.input`margin-top: 4px;`;

export default {
  WithTopOffset,
};
