import styled from 'styled-components';

export const WClearfix = styled.div`
  &:after :before {
    content: " ";
    display: table;
  }
  &:after {
    clear: both;
  }
`;
export default {
  WClearfix,
};
