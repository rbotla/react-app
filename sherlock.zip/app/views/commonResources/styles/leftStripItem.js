import styled from 'styled-components';
import Typography from '../typography';
import Colors from '../colorVariables';

export const LeftStripItem = styled.div`
  ${Typography.mediumLarge};
  ${Typography.mediumLargeHeight};
  ${Typography.defaultFontWeight};
  color: ${Colors.default};
  padding: 6px 0;
  cursor: pointer;

  &.padded {
    padding-left: 24px;
  }
`;

export default {
  LeftStripItem,
};
