export default {
  cardPadding: '0.625rem',
  leftStrip: '18px',
};
