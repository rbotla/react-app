// Utility for using multiple mixins without having to apply them in a long calling chain
export const withMixins = (component, mixins) => {
  return mixins.reduce((prev, current) => {
    // mixin can be either a function or an array with func at [0] and args from [1] on
    if (typeof current === 'function') {
      return current(prev);
    }
    const currentFunc = current[0];
    const args = current.slice(1);

    return currentFunc(prev, ...args);
  }, component);
};

export default withMixins;
