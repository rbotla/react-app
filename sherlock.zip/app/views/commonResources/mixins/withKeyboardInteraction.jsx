import React from 'react';
import PropTypes from 'prop-types';

export const withKeyboardInteraction = (Component) => {
  const INITIAL_STATE = {
    value: '',
  };
  class KeyboardInteractionWrapper extends React.Component {
    constructor(props) {
      super(props);
      this.state = INITIAL_STATE;
    }

    componentWillMount() {
      if (this.props.initialValue) {
        this.setState({ value: this.props.initialValue });
      }
    }

    onChange(e) {
      e.persist();
      this.setState({ value: e.target.value }, () => this.props.onChange(e, this.state));
    }

    render() {
      return (
        <Component
          {...this.props}
          onChange={e => this.onChange(e)}
          onKeyDown={e => this.props.onKeyDown(e, this.state)}
          onKeyPress={e => this.props.onKeyPress(e, this.state)}
          onKeyUp={e => this.props.onKeyUp(e, this.state)}
          onEnterPress={e => this.props.onEnterPress(e, this.state)}
          value={this.props.deferState ? this.props.deferState.value : this.state.value}
        />
      );
    }
  }

  KeyboardInteractionWrapper.defaultProps = {
    deferState: null,
    onChange: () => false,
    onKeyDown: () => false,
    onKeyPress: () => false,
    onKeyUp: () => false,
    onEnterPress: () => false,
    initialValue: null,
  };

  KeyboardInteractionWrapper.propTypes = {
    deferState: PropTypes.shape({
      value: PropTypes.string.isRequired,
    }),
    onChange: PropTypes.func,
    onKeyDown: PropTypes.func,
    onKeyPress: PropTypes.func,
    onKeyUp: PropTypes.func,
    onEnterPress: PropTypes.func,
    initialValue: PropTypes.string,
  };

  return KeyboardInteractionWrapper;
};

export default withKeyboardInteraction;
