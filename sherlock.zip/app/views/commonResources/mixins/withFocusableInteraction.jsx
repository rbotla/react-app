import React from 'react';
import PropTypes from 'prop-types';

export const withFocusableInteraction = (Component) => {
  const FocusableComponentWrapper = (props) => {
    return (
      <Component
        {...props}
        onFocus={e => props.onFocus(e)}
        onBlur={e => props.onBlur(e)}
      />
    );
  };

  FocusableComponentWrapper.defaultProps = {
    onFocus: () => false,
    onBlur: () => false,
  };

  FocusableComponentWrapper.propTypes = {
    onFocus: PropTypes.func,
    onBlur: PropTypes.func,
  };

  return FocusableComponentWrapper;
};

export default withFocusableInteraction;
