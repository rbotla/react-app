import React from 'react';
import PropTypes from 'prop-types';

export const withDeprecationWarning = (Component, warnings) => {
  class DeprecationWarningWrapper extends React.Component {
    componentDidMount() {
      warnings.forEach((warning) => {
        // warning can be either a string or object with properties of
        // deprecatedProperty: <string>, warningText: <function -> string>, deprecatedValues: <array[string]>
        if (typeof warning !== 'string') {
          const { deprecatedProperty, warningText, deprecatedValues } = warning;
          if (Array.isArray(deprecatedValues)) {
            deprecatedValues.forEach((depValue) => {
              if (this.props[deprecatedProperty] === depValue) console.warn(warningText(depValue));
            });
          } else if (this.props[deprecatedProperty]) {
            console.warn(warningText(deprecatedProperty));
          }
        } else {
          console.warn(warning);
        }
      });
    }
    render() {
      return (
        <Component
          {...this.props}
        />
      );
    }
  }

  return DeprecationWarningWrapper;
};

export default withDeprecationWarning;
