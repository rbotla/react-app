import React from 'react';
import PropTypes from 'prop-types';

export const withHoverableInteraction = (Component) => {
  const INITIAL_STATE = {
    isHovered: false,
  };
  class HoverableComponentWrapper extends React.Component {
    constructor(props) {
      super(props);
      this.state = INITIAL_STATE;
    }

    onMouseOver(e) {
      e.persist();
      this.setState({ isHovered: true }, () => this.props.onMouseOver(e, this.state));
    }

    onMouseOut(e) {
      e.persist();
      this.setState({ isHovered: false }, () => this.props.onMouseOut(e, this.state));
    }

    render() {
      return (
        <Component
          {...this.props}
          {...this.state}
          onMouseOver={e => this.onMouseOver(e)}
          onMouseOut={e => this.onMouseOut(e)}
          isHovered={this.state.isHovered}
        />
      );
    }
  }

  HoverableComponentWrapper.defaultProps = {
    onMouseOver: () => false,
    onMouseOut: () => false,
  };

  HoverableComponentWrapper.propTypes = {
    onMouseOver: PropTypes.func,
    onMouseOut: PropTypes.func,
  };

  return HoverableComponentWrapper;
};

export default withHoverableInteraction;
