import React from 'react';
import PropTypes from 'prop-types';

export const withDeprecationError = (Component, errors) => {
  class DeprecationErrorWrapper extends React.Component {
    componentDidMount() {
      errors.forEach((error) => {
        // error can be either a string or object with properties of
        // deprecatedProperty: <string>, errorText: <function -> string>, deprecatedValues: <array[string]>
        if (typeof error !== 'string') {
          const { deprecatedProperty, errorText, deprecatedValues } = error;
          if (Array.isArray(deprecatedValues)) {
            deprecatedValues.forEach((depValue) => {
              if (this.props[deprecatedProperty] === depValue) console.error(errorText(depValue));
            });
          } else if (this.props[deprecatedProperty]) {
            console.error(errorText(deprecatedProperty));
          }
        } else {
          console.error(error);
        }
      });
    }
    render() {
      return (
        <Component
          {...this.props}
        />
      );
    }
  }

  return DeprecationErrorWrapper;
};

export default withDeprecationError;
