import React from 'react';
import PropTypes from 'prop-types';

export const withCheckableInteraction = (Component) => {
  const INITIAL_STATE = {
    isChecked: false,
  };
  class CheckableComponentWrapper extends React.Component {
    constructor(props) {
      super(props);
      this.state = INITIAL_STATE;
    }

    onChange(e) {
      e.persist();
      this.setState({ isChecked: e.target.checked }, () => this.props.onChange(e, this.state));
    }

    render() {
      return (
        <Component
          {...this.props}
          onChange={e => this.props.onChange(e)}
          onClick={e => this.props.onClick(e, this.state)}
          isChecked={this.props.deferState ? this.props.deferState.isChecked : this.state.isChecked}
        />
      );
    }
  }

  CheckableComponentWrapper.defaultProps = {
    onChange: () => false,
    onClick: () => false,
    deferState: null,
  };

  CheckableComponentWrapper.propTypes = {
    onChange: PropTypes.func,
    onClick: PropTypes.func,
    deferState: PropTypes.shape({
      isChecked: PropTypes.bool.isRequired,
    }),
  };

  return CheckableComponentWrapper;
};

export default withCheckableInteraction;
