import React from 'react';
import PropTypes from 'prop-types';
import Tooltip from '../../Atoms/Tooltip/components/MixinTooltipStyle';
import { VisuallyHiddenText } from '../styles/a11y';

const INITIAL_STATE = {
  isTooltipShown: false,
  anchorHeight: 0,
  anchorWidth: 0,
  tooltipHeight: 0,
  tooltipWidth: 0,
};

const newTooltipLocationMap = {
  top: 'top-center',
  left: 'left-center',
  bottom: 'bottom-center',
  right: 'right-center',
};

export const withTooltip = (Component) => {
  class TooltipWrapper extends React.Component {
    constructor(config) {
      super(config);
      this.state = INITIAL_STATE;
    }

    componentDidMount() {
      this.captureTooltipDimensions();
    }

    shouldComponentUpdate(nextProps, nextState) {
      const isChangingVisibility = this.state.isTooltipShown !== nextState.isTooltipShown;
      const shouldRenderNowThatRefIsValid = this.state.tooltipHeight !== nextState.tooltipHeight;
      const areChildrenChanging = this.props.children !== nextProps.children;
      const isChangingTootipContent = this.props.tooltipContent !== nextProps.tooltipContent;
      const isChangingTooltipWidth = this.props.tooltipWidth !== nextProps.tooltipWidth;
      const isChangingTooltipPosition = this.props.tooltipPosition !== nextProps.tooltipPosition;
      const isChangingTooltipVisibility = this.props.hideTooltip !== nextProps.hideTooltip;

      return isChangingVisibility || shouldRenderNowThatRefIsValid || areChildrenChanging
        || isChangingTootipContent || isChangingTooltipWidth || isChangingTooltipPosition
        || isChangingTooltipVisibility;
    }

    componentDidUpdate() {
      this.captureTooltipDimensions();
    }

    captureTooltipDimensions() {
      this.setState({
        anchorHeight: (this.tooltipWrapper) ? this.tooltipWrapper.offsetHeight : 0,
        anchorWidth: (this.tooltipWrapper) ? this.tooltipWrapper.offsetWidth : 0,
        tooltipHeight: (this.tooltip) ? this.tooltip.offsetHeight : 0,
        tooltipWidth: (this.tooltip) ? this.tooltip.offsetWidth : 0,
      });
    }

    toggleTooltip(event, isActive = false) {
      this.setState({ isTooltipShown: isActive });
    }

    generateTooltipOffsets() {
      const { tooltipWidth, tooltipHeight, anchorHeight, anchorWidth } = this.state;
      const carrotToEdge = 10;
      const carrotHeight = 5;

      /* eslint-disable max-len */
      return {
        'top-center': [null, null, `${anchorHeight + carrotHeight}px`, `${(anchorWidth / 2) - (tooltipWidth / 2)}px`],
        'top-left': [null, null, `${anchorHeight + carrotHeight}px`, `${-tooltipWidth + (anchorWidth / 2) + carrotToEdge}px`],
        'top-right': [null, `${-tooltipWidth + (anchorWidth / 2) + carrotToEdge}px`, `${anchorHeight + carrotHeight}px`, null],
        'bottom-center': [`${anchorHeight + carrotHeight}px`, null, null, `${(-tooltipWidth / 2) + (anchorWidth / 2)}px`],
        'bottom-left': [`${anchorHeight + carrotHeight}px`, null, null, `${-tooltipWidth + (anchorWidth / 2) + carrotToEdge}px`],
        'bottom-right': [`${anchorHeight + carrotHeight}px`, `${-tooltipWidth + (anchorWidth / 2) + carrotToEdge}px`, null, null],
        'left-up': [null, `${anchorWidth + carrotHeight}px`, `${(anchorHeight / 2) - carrotToEdge}px`, null],
        'left-center': [`${(anchorHeight / 2) - (tooltipHeight / 2)}px`, `${anchorWidth + carrotHeight}px`, null, null],
        'left-down': [`${(anchorHeight / 2) - carrotToEdge}px`, `${anchorWidth + carrotHeight}px`, null, null],
        'right-up': [null, null, `${(anchorHeight / 2) - carrotToEdge}px`, `${anchorWidth + carrotHeight}px`],
        'right-center': [`${(anchorHeight / 2) - (tooltipHeight / 2)}px`, null, null, `${anchorWidth + carrotHeight}px`],
        'right-down': [`${(anchorHeight / 2) - carrotToEdge}px`, null, null, `${anchorWidth + carrotHeight}px`],
      };
      /* eslint-enable max-len */
    }

    render() {
      let tooltipPosition;
      /* Deprecate this logic */
      if (this.props.location) {
        tooltipPosition = newTooltipLocationMap[this.props.location];
      } else {
        tooltipPosition = this.props.tooltipPosition;
      }
      /* End */
      const tooltipClasses = ['tooltip', `tt-${tooltipPosition}`];

      if (this.state.isTooltipShown) tooltipClasses.push('shown');

      const [
        positionTop,
        positionRight,
        positionBottom,
        positionLeft
      ] = this.generateTooltipOffsets()[tooltipPosition];

      return (
        <span style={Object.assign({ position: 'relative', display: 'inline-block' }, { ...this.props.style })}>
          <div
            className="tooltip-wrapper"
            role="button"
            tabIndex="0"
            onMouseEnter={e => this.toggleTooltip(e, true)}
            onMouseLeave={e => this.toggleTooltip(e, false)}
            onFocus={e => this.toggleTooltip(e, true)}
            onBlur={e => this.toggleTooltip(e, false)}
            ref={(tooltipWrapper) => { this.tooltipWrapper = tooltipWrapper; }}
          >
            <VisuallyHiddenText>{this.props.tooltipContent || this.props.text}</VisuallyHiddenText>
            <Component
              {...this.props}
              isTooltipShown={this.state.isTooltipShown}
            />
          </div>

          { !this.props.hideTooltip
            ? <Tooltip
              innerRef={(tooltip) => { this.tooltip = tooltip; }}
              onFocus={e => this.toggleTooltip(e, true)}
              onBlur={e => this.toggleTooltip(e, false)}
              className={tooltipClasses.join(' ')}
              style={{
                top: positionTop,
                right: positionRight,
                bottom: positionBottom,
                left: positionLeft,
                width: `${this.props.tooltipWidth}px`,
              }}
            >
              {this.props.tooltipContent || this.props.text}
            </Tooltip>
            : null
          }
        </span>
      );
    }
  }

  TooltipWrapper.defaultProps = {
    tooltipContent: null,
    tooltipPosition: 'top-center',
    tooltipWidth: 200,
    hideTooltip: false,
    children: null,
    style: {},
    text: null,
    location: null,
  };

  TooltipWrapper.propTypes = {
    tooltipContent: (props) => {
      if (!props.tooltipContent && !props.text) {
        return new Error("One of props 'tooltipContent' or 'text' was not specified in 'Tooltip'.");
      }
    },
    tooltipPosition: PropTypes.oneOf([
      'top-center',
      'top-left',
      'top-right',
      'bottom-center',
      'bottom-left',
      'bottom-right',
      'left-up',
      'left-center',
      'left-down',
      'right-up',
      'right-center',
      'right-down',
    ]),
    tooltipWidth: PropTypes.number,
    hideTooltip: PropTypes.bool,
    children: PropTypes.node,
    style: PropTypes.objectOf(PropTypes.string),
    text: (props) => {
      if (!props.tooltipContent && !props.text) {
        return new Error("One of props 'tooltipContent' or 'text' was not specified in 'Tooltip'.");
      }
    },
    location: PropTypes.oneOf(['top', 'right', 'bottom', 'left']),
  };

  return TooltipWrapper;
};
export default withTooltip;
