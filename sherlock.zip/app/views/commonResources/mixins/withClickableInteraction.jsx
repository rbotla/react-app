import React from 'react';
import PropTypes from 'prop-types';

export const withClickableInteraction = (Component) => {
  const ClickableComponentWrapper = (props) => {
    return (
      <Component
        {...props}
        onClick={e => props.onClick(e)}
      />
    );
  };

  ClickableComponentWrapper.defaultProps = {
    onClick: () => false,
  };

  ClickableComponentWrapper.propTypes = {
    onClick: PropTypes.func,
  };

  return ClickableComponentWrapper;
};

export default withClickableInteraction;
