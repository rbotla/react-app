import React from 'react';
import PropTypes from 'prop-types';

export const DropdownCaret = (props) => {
  return (
    <svg className={props.className} width="32px" height="19px" viewBox="0 0 32 19" version="1.1" xmlns="http://www.w3.org/2000/svg">
      <g id="Page-1" stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
        <polygon className="dropdown-caret" id="Triangle" fill="#FFFFFF" points="16 19 0 0 32 0" />
      </g>
    </svg>
  );
};

DropdownCaret.defaultProps = {
  className: null,
};

DropdownCaret.propTypes = {
  className: PropTypes.string,
};

export default DropdownCaret;
