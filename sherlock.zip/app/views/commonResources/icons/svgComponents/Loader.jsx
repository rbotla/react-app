import React from 'react';
import PropTypes from 'prop-types';

import { Colors } from '../../../commonResources/colorVariables';

export const Loader = (props) => {
  return (
    <svg className={props.className} id={props.domID} width={props.length} height={props.length} viewBox="-6 -6 50 50" version="1.1" xmlns="http://www.w3.org/2000/svg" stroke={Colors.defaultLight}>
      <title>Loader</title>
      <g fill="none" fillRule="evenodd">
        <g transform="translate(1 1)" strokeWidth="4">
          <circle strokeOpacity=".3" cx="18" cy="18" r="18" />
          <path d="M36 18c0-9.94-8.06-18-18-18" transform="rotate(285.765 18 18)">
            <animateTransform attributeName="transform" type="rotate" from="0 18 18" to="360 18 18" dur="0.75s" repeatCount="indefinite" />
          </path>
        </g>
      </g>
    </svg>
  );
};

Loader.defaultProps = {
  domID: null,
  className: null,
  length: '50px',
};

Loader.propTypes = {
  domID: PropTypes.string,
  className: PropTypes.string,
  length: PropTypes.string,
};

export default Loader;
