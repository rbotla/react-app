import React from 'react';
import PropTypes from 'prop-types';

export const Collapse = (props) => {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width={props.length} height={props.length} viewBox="0 0 64 64" version="1.1" className={props.className}>
      <title>lg-collapse</title>
      <desc>Created with Sketch.</desc>
      <g id="Page-1" stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
        <g id="lg-collapse" fillRule="nonzero" fill="#393939" className="layout-control">
          <g id="collapse" transform="translate(14.000000, 14.000000)">
            <path d="M13,11 L13,1 C13,0.44771525 13.4477153,0 14,0 C14.5522847,0 15,0.44771525 15,1 L15,12.0371094 C15,13.527832 13.494873,15 11.9868164,15 L1,15 C0.44771525,15 0,14.5522847 0,14 C0,13.4477153 0.44771525,13 1,13 L11,13 L11,13 C12.1045695,13 13,12.1045695 13,11 Z M25,13 L35,13 C35.5522847,13 36,13.4477153 36,14 C36,14.5522847 35.5522847,15 35,15 L24.0563965,15 C22.5117188,15 21,13.5068359 21,11.980957 L21,1 C21,0.44771525 21.4477153,0 22,0 C22.5522847,0 23,0.44771525 23,1 L23,11 L23,11 C23,12.1045695 23.8954305,13 25,13 Z M11,23 L1,23 C0.44771525,23 0,22.5522847 0,22 C0,21.4477153 0.44771525,21 1,21 L12.0211182,21 C13.4677734,21 15,22.6499023 15,24.0722656 L15,35 C15,35.5522847 14.5522847,36 14,36 C13.4477153,36 13,35.5522847 13,35 L13,25 L13,25 C13,23.8954305 12.1045695,23 11,23 Z M23,25 L23,35 C23,35.5522847 22.5522847,36 22,36 C21.4477153,36 21,35.5522847 21,35 L21,24.0604248 C21,22.5524902 22.5180664,21 23.9888916,21 L35,21 C35.5522847,21 36,21.4477153 36,22 C36,22.5522847 35.5522847,23 35,23 L25,23 L25,23 C23.8954305,23 23,23.8954305 23,25 Z" id="Combined-Shape" />
          </g>
        </g>
      </g>
    </svg>
  );
};

Collapse.defaultProps = {
  className: undefined,
  length: '36px',
};

Collapse.propTypes = {
  className: PropTypes.string,
  length: PropTypes.string,
};

export default Collapse;
