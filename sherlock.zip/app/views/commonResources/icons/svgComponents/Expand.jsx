import React from 'react';
import PropTypes from 'prop-types';

export const Expand = (props) => {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width={props.length} height={props.length} viewBox="0 0 64 64" version="1.1" className={props.className}>
      <title>lg-expand</title>
      <desc>Created with Sketch.</desc>
      <g id="Page-1" stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
        <g id="lg-expand" fillRule="nonzero" fill="#393939" className="layout-control">
          <g id="expand" transform="translate(14.000000, 14.000000)">
            <path d="M2,4 L2,14 C2,14.5522847 1.55228475,15 1,15 C0.44771525,15 0,14.5522847 0,14 L0,3.07519531 C0,1.54931641 1.56298828,0 3.13085937,0 L14,0 C14.5522847,0 15,0.44771525 15,1 C15,1.55228475 14.5522847,2 14,2 L4,2 L4,2 C2.8954305,2 2,2.8954305 2,4 Z M32,2 L22,2 C21.4477153,2 21,1.55228475 21,1 C21,0.44771525 21.4477153,-1.0145306e-16 22,0 L33.0205078,0 C34.5097656,0 36,1.74853516 36,3.00390625 L36,14 C36,14.5522847 35.5522847,15 35,15 C34.4477153,15 34,14.5522847 34,14 L34,4 L34,4 C34,2.8954305 33.1045695,2 32,2 Z M4,34 L14,34 C14.5522847,34 15,34.4477153 15,35 C15,35.5522847 14.5522847,36 14,36 L3.10913086,36 C1.69213867,36 0,34.4731445 0,33.0419922 L0,22 C3.381769e-17,21.4477153 0.44771525,21 1,21 C1.55228475,21 2,21.4477153 2,22 L2,32 L2,32 C2,33.1045695 2.8954305,34 4,34 Z M34,32 L34,22 C34,21.4477153 34.4477153,21 35,21 C35.5522847,21 36,21.4477153 36,22 L36,33.0419922 C36,34.4060059 34.5249023,36 33.0217285,36 L22,36 C21.4477153,36 21,35.5522847 21,35 C21,34.4477153 21.4477153,34 22,34 L32,34 L32,34 C33.1045695,34 34,33.1045695 34,32 Z" id="Combined-Shape" />
          </g>
        </g>
      </g>
    </svg>
  );
};

Expand.defaultProps = {
  className: undefined,
  length: '36px',
};

Expand.propTypes = {
  className: PropTypes.string,
  length: PropTypes.string,
};

export default Expand;
