import React from 'react';
import PropTypes from 'prop-types';

export const Popout = (props) => {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width={props.length} height={props.length} viewBox="0 0 64 64" version="1.1" className={props.className}>
      <g stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
        <g fillRule="nonzero" fill="#393939" className="layout-control">
          <g transform="translate(14.000000, 14.000000)">
            <path d="M10,4 L10,24 L10,24 C10,25.1045695 10.8954305,26 12,26 L32,26 L32,26 C33.1045695,26 34,25.1045695 34,24 L34,4 L34,4 C34,2.8954305 33.1045695,2 32,2 L12,2 L12,2 C10.8954305,2 10,2.8954305 10,4 Z M11.0258789,0 C11.9949544,0 19.331543,0 33.0356445,0 C34.4191895,0 36,1.50512695 36,3.03320312 L36,24.9858398 C36,26.4729004 34.4902344,28 33.0356445,28 L11.0258789,28 C9.50439453,28 8,26.5527344 8,24.9858398 L8,3.03320312 C8,1.3425293 9.57226562,0 11.0258789,0 Z" id="Rectangle-14" />
            <path d="M27.0124512,27 C27.5647359,27 27,27.4477153 27,28 L27,33.1496582 C27,34.3867188 25.5012207,36 24.0908203,36 L3.0625,36 C1.54418945,36 0,34.513916 0,33.1496582 L0,12.072998 C0,10.5170898 1.6574707,9 3.0625,9 C3.9991862,9 6.31583659,9 10.0124512,9 C10.0006104,9 10.0124512,9.4477153 10.0124512,10 L10.0124512,26.0012207 L27.0124512,27 Z M8.01843262,11 L4,11 L4,11 C2.8954305,11 2,11.8954305 2,13 L2,32 L2,32 C2,33.1045695 2.8954305,34 4,34 L23,34 L23,34 C24.1045695,34 25,33.1045695 25,32 L25,27.9128418 L11.0300293,27.9128418 C10.1452637,27.9128418 8.01843262,25.986084 8.01843262,24.2900391 L8.01843262,11 Z" id="Path-2" />
          </g>
        </g>
      </g>
    </svg>
  );
};

Popout.defaultProps = {
  className: undefined,
  length: '36px',
};

Popout.propTypes = {
  className: PropTypes.string,
  length: PropTypes.string,
};

export default Popout;
