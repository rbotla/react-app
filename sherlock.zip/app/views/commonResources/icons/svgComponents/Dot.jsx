import React from 'react';
import PropTypes from 'prop-types';

export const Dot = (props) => {
  return (
    <svg className={props.className} width={props.width} height={props.height} viewBox="0 0 26 26" version="1.1" xmlns="http://www.w3.org/2000/svg">
      <title>Oval 2</title>
      <g id="Page-1" stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
        <circle id="Oval-2" fill="#000000" cx="13" cy="13" r="13" />
      </g>
    </svg>
  );
};

Dot.defaultProps = {
  className: undefined,
  width: '26px',
  height: '26px',
};

Dot.propTypes = {
  className: PropTypes.string,
  width: PropTypes.string,
  height: PropTypes.string,
};

export default Dot;
