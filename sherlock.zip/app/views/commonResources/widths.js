export default {
  leftStrip: '320px',
};
