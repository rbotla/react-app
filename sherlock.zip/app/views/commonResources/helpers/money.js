// Helper methods taken from Project X
export const numberWithCommas = (number) => {
  return (`${number}`).replace(/(\d)(?=(\d\d\d)+(?!\d))/g, '$1,');
};

export const roundFloatToHundredths = (float) => {
  return (Math.round(float * 100) / 100).toFixed(2);
};

export const floatToDollarString = (float) => {
  return `$${numberWithCommas(roundFloatToHundredths(float))}`;
};
