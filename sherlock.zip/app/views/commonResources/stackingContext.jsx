export default {
  leftStrip: `
    z-index: 10;
  `,
  dropdownMain: `
    z-index: 900;
  `,
  barWrapper: `
    z-index: 901;
  `,
  zIndexThree: `
    z-index: 3;
  `,
  zIndexFour: `
    z-index: 4;
  `,
};
