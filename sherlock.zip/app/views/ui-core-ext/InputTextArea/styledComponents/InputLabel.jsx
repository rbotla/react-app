import styled from 'styled-components';
import { Colors } from '../../../commonResources/colorVariables';
import { Typography } from '../../../commonResources/typography';

export default styled.label`
  display: block;
  margin-bottom: 0.3rem;
  color: ${Colors.default};
  ${Typography.small};
  ${Typography.defaultLineHeight};
  ${Typography.bold};
  letter-spacing: 0.5px;
  text-transform: uppercase;
`;
