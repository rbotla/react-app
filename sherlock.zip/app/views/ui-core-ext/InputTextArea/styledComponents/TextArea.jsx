import styled from 'styled-components';
import { Colors } from '../../../commonResources/colorVariables';
import { Borders } from '../../../commonResources/borders';
import { Typography } from '../../../commonResources/typography';

export default styled.textarea`
  display: block;
  width: 100%;
  min-height: 90px;
  overflow: hidden;
  resize: auto;
  padding: 10px 8px;
  padding-right: ${props => props.paddingRight}px;
  ${Borders.lightSecondaryGrey};
  ${Borders.smallBorderRadius};
  box-shadow: inset 0 2px 2px 0 ${Colors.lighterGrey};
  ${Typography.default};
  color: ${Colors.darkerGrey};
  background-color: ${Colors.white};

  &:hover {
    ${Borders.secondary30};
  }

  &:focus {
    outline: none;
    ${Borders.darkestSecondaryGrey};
  }
`;

// styled.input`
//   display: block;
//   width: 100%;
//   height: 120px;
//   padding: 10px 8px;
//   padding-right: ${props => props.paddingRight}px;
//   ${Borders.lightSecondaryGrey};
//   ${Borders.smallBorderRadius};
//   box-shadow: inset 0 2px 2px 0 ${Colors.lighterGrey};
//   ${Typography.default};
//   color: ${Colors.darkerGrey};
//   background-color: ${Colors.white};

//   &:hover {
//     ${Borders.secondary30};
//   }

//   &:focus {
//     outline: none;
//     ${Borders.darkestSecondaryGrey};
//   }
// `;
  // padding: 0 7px;
  // margin: 0 0 30px;
  // width: 500px;
  // height: ${props => (props.style && props.style.height) ? props.style.height + 'px' : '0px'};
