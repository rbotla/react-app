import React from 'react';
import PropTypes from 'prop-types';
import TextArea from './styledComponents/TextArea';
import Wrapper from './styledComponents/Wrapper';
import InputLabel from './styledComponents/InputLabel';
import withKeyboardInteraction from '../../commonResources/mixins/withKeyboardInteraction';

export class InputTextArea extends React.Component {
  onEnterPress(e) {
    const keyCode = e.keyCode || e.which;
    if (keyCode === 13) this.props.onEnterPress(e);
  }

  render() {
    if (this.props.label && !this.props.domID) {
      console.warn('Please enter valid "domID" prop into Input component for accessibility.');
    }
    return (
      <Wrapper className={this.props.className}>
        { this.props.label
          ? <InputLabel htmlFor={this.props.domID}>{this.props.label}</InputLabel>
          : null
        }
        <TextArea
          id={this.props.domID}
          value={this.props.value}
          onChange={e => this.props.onChange(e)}
          onKeyPress={e => this.onEnterPress(e)}
          placeholder={this.props.placeholder}
          paddingRight={this.props.paddingRight}
        />
      </Wrapper>
    );
  }
}

InputTextArea.defaultProps = {
  className: '',
  label: null,
  onEnterPress: () => {},
  placeholder: '',
  onChange: () => {},
  domID: null,
  paddingRight: 8,
};

InputTextArea.propTypes = {
  onEnterPress: PropTypes.func.isRequired,
  onChange: PropTypes.func.isRequired,
  value: PropTypes.string.isRequired,
  className: PropTypes.string,
  label: PropTypes.string,
  placeholder: PropTypes.string,
  domID: PropTypes.string,
  paddingRight: PropTypes.number,
};

export default withKeyboardInteraction(InputTextArea);
