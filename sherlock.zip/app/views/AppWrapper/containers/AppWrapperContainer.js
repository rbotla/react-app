import { connect } from 'react-redux';
import AppWrapper from '../components/AppWrapper';
import { 
  makeSelectMasthead,
  makeSelectIsDashboardRequestModalOpen,
  makeSelectIsReportAProblemModalOpen,
  makeSelectIsWhatIsSherlockModalOpen,
} from '../modules/selectors';
import { 
  onRequestTestApiTimestamp,
  onSupportMenuItemSelect,
  onDashboardModalClose,
  onDashboardRequestSubmit,
  onReportAProblemModalClose,
  onReportAProblemSubmit,
  onWhatIsSherlockModalClose,
 } from '../modules/actions';

const mapDispatchToProps = (dispatch, ownProps) => {
  const { router } = ownProps;
  return {
    mastheadActions: {
      onProductMenuOpenClose: () => false,
      onSupportMenuOpenClose: () => false,
      supportMenuSearch: () => false,
      onSupportMenuSelect: (x, y) => dispatch(onSupportMenuItemSelect(y.activeSectionIndex, y.activeMenuItemIndex)),
      onNavMenuSelect: (event, item) => {
        router.push(item.path);
        return dispatch(onRequestTestApiTimestamp());
      },
      onProductMenuSelect: (event, state) => dispatch(onProductMenuSelect(state)),
    },
    onDashboardModalClose: () => dispatch(onDashboardModalClose()),
    onDashboardRequestSubmit: (data) => dispatch(onDashboardRequestSubmit(data)),
    onReportAProblemModalClose: () => dispatch(onReportAProblemModalClose()),
    onWhatIsSherlockModalClose: () => dispatch(onWhatIsSherlockModalClose()),
    onReportAProblemSubmit: (data) => dispatch(onReportAProblemSubmit(data)),
  };
};

const mapStateToProps = (state) => {
  const mastheadConfig = makeSelectMasthead()(state);
  const isDashboardRequestModalOpen = makeSelectIsDashboardRequestModalOpen()(state);
  const isReportAProblemModalOpen = makeSelectIsReportAProblemModalOpen()(state);
  const isWhatIsSherlockModalOpen = makeSelectIsWhatIsSherlockModalOpen()(state);
  return {
    ...state,
    mastheadConfig,
    isDashboardRequestModalOpen,
    isReportAProblemModalOpen,
    isWhatIsSherlockModalOpen,
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(AppWrapper);
