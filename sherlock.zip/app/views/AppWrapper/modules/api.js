import { DOMAIN, ENDPOINTS, HEADERS } from '../../../constants/api';

export default {
  saveNewRequest: (data) => {
    let reqData = new Object();
    reqData['request_type'] = data.requestType;
    reqData['email'] = data.email;
    reqData['details'] = data.requestDetails;
    return (
    fetch(`${DOMAIN}/${ENDPOINTS.SUPPORT}`,
        { headers: HEADERS.APPLICATION_POST_JSON,
          method: 'post',
          body: JSON.stringify(reqData) 
        }
      ).then((fetchResponseObj) => {
        try {
          return fetchResponseObj.json();
        } catch (e) {
          console.error(e)
          return e;
        }
      })
    )
  }
};


