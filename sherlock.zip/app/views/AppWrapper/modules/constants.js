export const PRODUCT_MENU_ITEMS = [
  [
    {
      id: 0,
      label: 'Sherlock Data Analytics',
      path: '/',
    }
  ]
];

export const SUPPORT_MENU_ITEMS = [
  [
    {
      id: 0,
      label: 'Request a New Dashboard',
      path: '/',
    },
    {
      id: 1,
      label: 'Report a Problem',
      path: '/',
    }
  ],
  [
    {
      id: 2,
      label: 'What is Sherlock Data Analytics?',
      path: '/',
    }
  ]
];

export const ON_PRODUCT_MENU_SELECT = 'app/views/AppWrapper/ON_PRODUCT_MENU_SELECT';

export const ON_DASHBOARD_REQUEST_SUBMIT = 'app/views/AppWrapper/ON_DASHBOARD_REQUEST_SUBMIT';
export const ON_DASHBOARD_REQUEST_SUCCEEDED = 'app/views/AppWrapper/ON_DASHBOARD_REQUEST_SUCCEEDED';
export const ON_DASHBOARD_REQUEST_FAILED = 'app/views/AppWrapper/ON_DASHBOARD_REQUEST_FAILED';
export const ON_SUPPORT_MENU_ITEM_SELECT = 'app/views/AppWrapper/ON_SUPPORT_MENU_ITEM_SELECT';
export const ON_DASHBOARD_REQUEST_CLOSE = 'app/views/AppWrapper/ON_DASHBOARD_REQUEST_CLOSE';
export const ON_REPORT_A_PROBLEM_CLOSE = 'app/views/AppWrapper/ON_REPORT_A_PROBLEM_CLOSE';
export const ON_REPORT_A_PROBLEM_SUBMIT = 'app/views/AppWrapper/ON_REPORT_A_PROBLEM_SUBMIT';
export const ON_REPORT_A_PROBLEM_SUCCEEDED = 'app/views/AppWrapper/ON_REPORT_A_PROBLEM_SUCCEEDED';
export const ON_REPORT_A_PROBLEM_FAILED = 'app/views/AppWrapper/ON_REPORT_A_PROBLEM_FAILED';
export const ON_WHAT_IS_SHERLOCK_CLOSE = 'app/views/AppWrapper/ON_WHAT_IS_SHERLOCK_CLOSE';

export const TEST_API_REQUESTED = 'app/views/AppWrapper/TEST_API_REQUESTED';
export const TEST_API_SUCCEEDED = 'app/views/AppWrapper/TEST_API_SUCCEEDED';
export const TEST_API_FAILED = 'app/views/AppWrapper/TEST_API_FAILED';
