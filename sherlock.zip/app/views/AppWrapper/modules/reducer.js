/*
 * AppReducer
 *
 * The reducer takes care of our data. Using actions, we can change our
 * application state.
 * To add a new action, add it to the switch statement in the reducer function
 *
 * Example:
 * case YOUR_ACTION_CONSTANT:
 *   return state.set('yourStateVariable', true);
 */

import { fromJS } from 'immutable';
import {
  PRODUCT_MENU_ITEMS,
  SUPPORT_MENU_ITEMS,
  ON_PRODUCT_MENU_SELECT,
  TEST_API_SUCCEEDED,
  ON_DASHBOARD_REQUEST_SUCCEEDED,
  ON_DASHBOARD_REQUEST_FAILED,
  ON_SUPPORT_MENU_ITEM_SELECT,
  ON_DASHBOARD_REQUEST_CLOSE,
  ON_REPORT_A_PROBLEM_CLOSE,
  ON_REPORT_A_PROBLEM_SUCCEEDED,
  ON_REPORT_A_PROBLEM_FAILED,
  ON_WHAT_IS_SHERLOCK_CLOSE,
} from './constants';

// The initial state of the App
const initialState = fromJS({
  productMenuItems: PRODUCT_MENU_ITEMS,
  currentProductSectionIndex: 0,
  currentProductItemIndex: 0,
  supportMenuItems: SUPPORT_MENU_ITEMS,
  testSagaTimestamp: 0,
  isDashboardRequestModalOpen: false,
  isReportAProblemModalOpen: false,
  isWhatIsSherlockModalOpen: false,
  message: '',
});

function AppReducer(state = initialState, action) {
  switch (action.type) {
    case ON_PRODUCT_MENU_SELECT:
      return state.merge({
        currentProductSectionIndex: action.state.activeSectionIndex,
        currentProductItemIndex: action.state.activeMenuItemIndex,
      });
      break;

    case TEST_API_SUCCEEDED:
      return state.set('testSagaTimestamp', action.timestamp);
      break;

    case ON_DASHBOARD_REQUEST_SUCCEEDED:
      return state.merge({
        isDashboardRequestModalOpen: false,
        message: 'Your new Dashboard Request has been created successfully.'
      })
      break;

    case ON_DASHBOARD_REQUEST_FAILED:
      console.error(action.message)
      return state.merge({
        isDashboardRequestModalOpen: false,//true,
        message: action.message
      })
      break;

     case ON_SUPPORT_MENU_ITEM_SELECT:
      switch (action.sectionIndex) {
        case 0:
          if (action.menuIndex === 0) {
            return state.set('isDashboardRequestModalOpen', true)
          }
          else if (action.menuIndex === 1) {
            return state.set('isReportAProblemModalOpen', true)
          }
          break;

        case 1:
          if (action.menuIndex === 0) return state.set('isWhatIsSherlockModalOpen', true);      
          break;

      }
      break;

     case ON_DASHBOARD_REQUEST_CLOSE:
      return state.set('isDashboardRequestModalOpen', false);      
      break;

     case ON_REPORT_A_PROBLEM_CLOSE:
      return state.set('isReportAProblemModalOpen', false);
      break;

    case ON_REPORT_A_PROBLEM_SUCCEEDED:
      return state.merge({
        isReportAProblemModalOpen: false,
        message: 'Your request has been submitted successfully.'
      })
      break;

    case ON_REPORT_A_PROBLEM_FAILED:
      console.error(action.message)
      return state.merge({
        isReportAProblemModalOpen: false, //true,
        message: action.message
      })
      break;

     case ON_WHAT_IS_SHERLOCK_CLOSE:
      return state.set('isWhatIsSherlockModalOpen', false);
      break;

    default:
      return state;
  }
}

export default AppReducer;
