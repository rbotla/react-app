/*
 * App Actions
 *
 * Actions change things in your application
 * Since this boilerplate uses a uni-directional data flow, specifically redux,
 * we have these actions which are the only way your application interacts with
 * your application state. This guarantees that your state is up to date and nobody
 * messes it up weirdly somewhere.
 *
 * To add a new Action:
 * 1) Import your constant
 * 2) Add a function like this:
 *    export function yourAction(var) {
 *        return { type: YOUR_ACTION_CONSTANT, var: var }
 *    }
 */
import {
  ON_PRODUCT_MENU_SELECT,
  TEST_API_REQUESTED,
  ON_DASHBOARD_REQUEST_SUBMIT,
	ON_REPORT_A_PROBLEM_SUBMIT,
	ON_SUPPORT_MENU_ITEM_SELECT,
  ON_DASHBOARD_REQUEST_CLOSE,
  ON_REPORT_A_PROBLEM_CLOSE,
  ON_WHAT_IS_SHERLOCK_CLOSE,
} from './constants';

export const onProductMenuSelect = (state) => ({
  type: ON_PRODUCT_MENU_SELECT,
  state,
});

export const onRequestTestApiTimestamp = () => ({
  type: TEST_API_REQUESTED,
});

export const onDashboardRequestSubmit = (data) => {
return ({
  type: ON_DASHBOARD_REQUEST_SUBMIT,
  data
})
}

export const onSupportMenuItemSelect = (sectionIndex, menuIndex) => ({
  type: ON_SUPPORT_MENU_ITEM_SELECT,
  sectionIndex,
  menuIndex
});

export const onDashboardModalClose = () => {
  return ({
    type: ON_DASHBOARD_REQUEST_CLOSE
  })
}

export const onReportAProblemModalClose = () => {
  return ({
    type: ON_REPORT_A_PROBLEM_CLOSE
  })
}

export const onReportAProblemSubmit = (data) => ({
  type: ON_REPORT_A_PROBLEM_SUBMIT,
  data
});

export const onWhatIsSherlockModalClose = () => {
  return ({
    type: ON_WHAT_IS_SHERLOCK_CLOSE
  })
}
