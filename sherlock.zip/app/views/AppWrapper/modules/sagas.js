import { call, put, takeLatest } from 'redux-saga/effects';
import {
  TEST_API_REQUESTED,
  TEST_API_SUCCEEDED,
  TEST_API_FAILED,
  ON_DASHBOARD_REQUEST_SUBMIT,
  ON_DASHBOARD_REQUEST_SUCCEEDED,
  ON_DASHBOARD_REQUEST_FAILED,
  ON_REPORT_A_PROBLEM_SUBMIT,
  ON_REPORT_A_PROBLEM_SUCCEEDED,
  ON_REPORT_A_PROBLEM_FAILED
} from './constants';
import Api from './api';

// const Api = {
//   testRequest: () => {
//     const promise = new Promise((resolve) => setTimeout(resolve(Date.now()), 1000));
//     return promise;
//   },
// };

// worker Saga: will be fired on TEST_API_REQUESTED actions
function* testRequest(/* action */) {
  try {
    const timestamp = yield call(Api.testRequest/* , action.payload.userId */);
    yield put({ type: TEST_API_SUCCEEDED, timestamp });
  } catch (e) {
    yield put({ type: TEST_API_FAILED, message: e.message });
  }
}

function* submitNewDashboardRequest(action) {
  try {
    const data = yield call(Api.saveNewRequest, action.data);
    yield put({ type: ON_DASHBOARD_REQUEST_SUCCEEDED });
  } catch (e) {
    yield put({ type: ON_DASHBOARD_REQUEST_FAILED, message: e.message });
  }
}

function* submitReportAProblemRequest(action) {
  try {
    const data = yield call(Api.saveNewRequest, action.data);
    yield put({ type: ON_REPORT_A_PROBLEM_SUCCEEDED });
  } catch (e) {
    yield put({ type: ON_REPORT_A_PROBLEM_FAILED, message: e.message });
  }
}

function* rootSaga() {
  yield takeLatest(TEST_API_REQUESTED, testRequest);
  yield takeLatest(ON_DASHBOARD_REQUEST_SUBMIT, submitNewDashboardRequest);
  yield takeLatest(ON_REPORT_A_PROBLEM_SUBMIT, submitReportAProblemRequest);
}

export default {
  rootSaga,
};
