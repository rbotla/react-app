/**
 * The global state selectors
 */

import { createSelector } from 'reselect';

const selectGlobal = (state) => state.get('app');

const makeSelectMasthead = () => createSelector(
  selectGlobal,
  (globalState) => ({
    productMenuItems: globalState.get('productMenuItems').toJS(),
    currentProductName: globalState.getIn([
      'productMenuItems',
      globalState.get('currentProductSectionIndex'),
      globalState.get('currentProductItemIndex'),
      'label',
    ]),
    supportMenuItems: globalState.get('supportMenuItems').toJS(),
  })
);

const makeSelectLocationState = () => {
  let prevRoutingState;
  let prevRoutingStateJS;

  return (state) => {
    const routingState = state.get('route'); // or state.route

    if (!routingState.equals(prevRoutingState)) {
      prevRoutingState = routingState;
      prevRoutingStateJS = routingState.toJS();
    }

    return prevRoutingStateJS;
  };
};

const makeSelectIsDashboardRequestModalOpen = () => createSelector(
  selectGlobal,
  (state) => {
      return state.get('isDashboardRequestModalOpen');
});

const makeSelectIsReportAProblemModalOpen = () => createSelector(
  selectGlobal,
  (state) => {
      return state.get('isReportAProblemModalOpen');
});

const makeSelectIsWhatIsSherlockModalOpen = () => createSelector(
  selectGlobal,
  (state) => {
      return state.get('isWhatIsSherlockModalOpen');
});

export {
  selectGlobal,
  makeSelectMasthead,
  makeSelectLocationState,
  makeSelectIsDashboardRequestModalOpen,
  makeSelectIsReportAProblemModalOpen,
  makeSelectIsWhatIsSherlockModalOpen
};
