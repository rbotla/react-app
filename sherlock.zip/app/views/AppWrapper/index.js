import AppWrapperContainer from './containers/AppWrapperContainer';

export default AppWrapperContainer;
