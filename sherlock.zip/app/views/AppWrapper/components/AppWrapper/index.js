import React from 'react';
import Helmet from 'react-helmet';
import {Masthead} from 'ui-core';
import {Modal} from 'ui-core';
import NewDashboardForm from '../Support/NewDashboardForm.jsx'
import ReportAProblemForm from '../Support/ReportAProblemForm.jsx'
import WhatisSherlock from '../Support/WhatisSherlock.jsx'

import './styles.scss';

export const App = (props) => (
  <div>
    <Helmet
      titleTemplate="%s - Sherlock Data Analytics"
      defaultTitle="Sherlock Data Analytics"
      meta={[
        { name: 'description', content: 'Sherlock Data Analytics' },
      ]}
    />

    <Masthead
      {...props.mastheadConfig}
      {...props.mastheadActions}
    />

    <div id="main_content">
      {React.Children.toArray(props.children)}
    </div>

    {
      props.isDashboardRequestModalOpen ? 
      <Modal
        children={
          <NewDashboardForm 
              onCancel={props.onDashboardModalClose}
              onSubmit={props.onDashboardRequestSubmit}
              />
        }
        domID="new-dashboard-modal-id"
        onClickOut={() => props.onDashboardModalClose()}
        onModalToggle={() => props.onDashboardModalClose()}
        isOpen={true}
      />
      : null
    }

    {
      props.isReportAProblemModalOpen ? 
      <Modal
        children={
          <ReportAProblemForm 
              onCancel={props.onReportAProblemModalClose}
              onSubmit={props.onReportAProblemSubmit}
              />
        }
        domID="report-a-problem-modal-id"
        onClickOut={() => props.onReportAProblemModalClose()}
        onModalToggle={() => props.onReportAProblemModalClose()}
        isOpen={true}
      />
      : null
    }

    { props.isWhatIsSherlockModalOpen ? 
      <Modal
        children={
          <WhatisSherlock onClose={props.onWhatIsSherlockModalClose}/>
        }
        domID="what-is-sherlock-modal-id"
        onClickOut={() => props.onWhatIsSherlockModalClose()}
        onModalToggle={() => props.onWhatIsSherlockModalClose()}
        isOpen={true}
      />
      : null
    }
  </div>
);

App.propTypes = {
  children: React.PropTypes.node,
  mastheadConfig: React.PropTypes.object,
  mastheadActions: React.PropTypes.object,
  isDashboardRequestModalOpen: React.PropTypes.bool,
  onDashboardModalClose: React.PropTypes.func,
  onDashboardRequestSubmit: React.PropTypes.func,
  isReportAProblemModalOpen: React.PropTypes.bool,
  isWhatIsSherlockModalOpen: React.PropTypes.bool,
  onReportAProblemModalClose: React.PropTypes.func,
  onReportAProblemSubmit: React.PropTypes.func,
  onWhatIsSherlockModalClose: React.PropTypes.func,
};

export default App;
