import React from 'react';
import PropTypes from 'prop-types';
import SupportFormWrapper from '../../../styledComponents/SupportFormWrapper.jsx';
import Space from '../../../styledComponents/Space.jsx';
import Footer from '../../../styledComponents/RequestFormFooter.jsx';
import {SectionTitle, Button } from  'ui-core';

import styled from 'styled-components';

const FlexBoxRow = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  margin-top: 1em;
`;

const FlexBoxColumn = styled.div`
  display: flex;
  flex-direction: column;
  margin-top: 1em;
`;

const WhatIsSherlock = (props) => (
	<SupportFormWrapper>
    <SectionTitle
      title={'What is Sherlock Data Analytics?'}
      className="title"
    />
		<FlexBoxColumn>
			<FlexBoxRow>
        <div> 
        	<img src="https://s3.amazonaws.com/edw-chc-prod-datasolutions/sherlock-web-app/images/Sherlock_150.png"/>
        </div>
        <div style={{marginLeft: "15px", fontSize: "small"}}>
          <ul >
            <li>Built on the premise of Design Thinking, Sherlock is a solution to solve users’ pain point of finding BI dashboards for their needs.</li>
            <li>Search the inventory of BI assets through Sherlock’s different lenses.</li>
            <li>Access different BI dashboards whether it’s on Spotfire, Tableau, Incorta, etc.</li>
          </ul>
        </div>
			</FlexBoxRow>
			<FlexBoxRow>
				<div style={{fontSize: "small", marginRight: "15px"}}>
          Built on CHC Technology:
          <ul>
            <li>Built on Amazon’s AWS’ serverless microservices architecture (Lambda, ElasticSearch, DynamoDB, and API Gateway).</li>
            <li>Stood up using the CHC IHP framework and its principles.</li>
          </ul>
				</div>
        <div style={{fontSize: "small"}}>
          <div><b>[Q]</b> My team has other BI assets that isn’t on Sherlock. Can we get it to show up in Sherlock?</div>
          <div style={{marginTop: "5px"}}><b>[A]</b> Yes! Sherlock is open to all internal BI assets.  To add it to Sherlock, please reach out to sherlocksupport@changehealthcare.com.</div>
          <div style={{marginTop: "20px"}}><b>[Q]</b> I can’t access a dashboard in the search results. Why?</div>
          <div style={{marginTop: "5px"}}><b>[A]</b> Most likely the dashboard itself needs a secondary level of access permissions. Click the Request access link for that dashboard.</div>
        </div>
			</FlexBoxRow>
		</FlexBoxColumn>
	</SupportFormWrapper>
)

WhatIsSherlock.defaultProps = {
};

WhatIsSherlock.propTypes = {
  onClose: PropTypes.func,
};

export default WhatIsSherlock;