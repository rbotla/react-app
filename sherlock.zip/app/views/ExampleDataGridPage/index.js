import ExampleDataGridPageContainer from './containers/ExampleDataGridPageContainer';

export default ExampleDataGridPageContainer;
