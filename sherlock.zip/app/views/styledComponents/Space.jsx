import styled from 'styled-components';

export default styled.div`
  margin-left: .5em;
`;
