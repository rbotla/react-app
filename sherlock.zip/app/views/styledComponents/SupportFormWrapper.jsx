import styled from 'styled-components';
import { Colors } from '../commonResources/colorVariables';
import Typography from '../commonResources/typography';
import { BoxShadows } from '../commonResources/boxShadows';
import { Borders } from '../commonResources/borders';

export default styled.form`
  background-color: ${Colors.white};
  padding: 1.5em 2em;

  .title {
    ${Typography.heading};
    margin: 0 0 0.5em 0;
  }

  .text-input {
    margin-bottom: 0.5em;
  }

  .sign-in-cta {
    float: right;
  }

  @media(max-width: 480px) {
    .sign-in-cta {
      float: none;
      display: block;
      margin-left: 0;
      margin-top: 0.5em;
    }
  }
`;

