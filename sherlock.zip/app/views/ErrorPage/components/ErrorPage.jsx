import React from 'react';
// import PropTypes from 'prop-types';



export const ErrorPage = (/* props */) => (
  <div>
    An Error Has Occurred
  </div>
);

/*
ErrorPage.defaultProps = {

};

ErrorPage.propTypes = {

};

*/

export default ErrorPage;
