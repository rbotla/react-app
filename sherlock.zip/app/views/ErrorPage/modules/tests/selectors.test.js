
// import { fromJS } from 'immutable';
// import { makeSelect } from '../selectors';

// const selector = makeSelect();

describe('makeSelect', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
