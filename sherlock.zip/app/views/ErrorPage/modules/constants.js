/*
 *
 * ErrorPage constants
 *
 */
export const EXAMPLE_CONSTANT = 'EXAMPLE_CONSTANT';
