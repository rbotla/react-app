import { connect } from 'react-redux';
import ErrorPage from '../components/ErrorPage.jsx';

const mapDispatchToProps = {
};


export default connect(null, mapDispatchToProps)(ErrorPage);
