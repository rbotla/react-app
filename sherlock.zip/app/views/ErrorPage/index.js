import ErrorPage from './containers/ErrorPageContainer';

export default ErrorPage;
