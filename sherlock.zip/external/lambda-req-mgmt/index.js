const AWS = require('aws-sdk');
const fs = require('fs');
const uuid = require('node-uuid');

//Read config values from a JSON file.
//let config = fs.readFileSync('./app_config.json', 'utf8');
//config = JSON.parse(config);

//AWS.config.update({
//    region: config.region,
//    endpoint: config.endpoint,
//    accessKeyId: config.accessKeyId,
//    secretAccessKey: config.secretAccessKey
//});

const dynamo = new AWS.DynamoDB();
const docClient = new AWS.DynamoDB.DocumentClient();
const tableName = 'edw_sherlock_requests'; //'etpm_sehrlock_requests';

exports.handler = (event, context, callback) => {

    if (typeof event === 'string') event = JSON.parse(event);
    //logInput(event);
    var marker = event.path.lastIndexOf("/");   
    var resource = event.path.substr(marker+1);

    switch(resource) {
        case 'support':
            if (event.httpMethod === 'GET') {
                getAllRequests(context, callback);
            }
            else if (event.httpMethod === 'POST') {
                const doc = event.body;
                createNewRequest(doc, context, callback);
            }
            break;
        default:
            callback('Method not supported yet.', null)
    }
    //callback(null, responseData);
};


function getAllRequests(context, callback) {
    const params = {
        TableName: tableName,
        ProjectionExpression: "#request_id, #request_type, email, details, creation_date, #status",
        ExpressionAttributeNames: {
            "#request_id": "request_id",
            "#request_type": "request_type",
            "#status": "status"
        }
    };

    docClient.scan(params, function(err, data) {
        if (err) {
            const errStr = '{"response": "Unable to query. Error: "+JSON.stringify(err, null, 2)}';
            console.error(errStr);

            callback(errStr, null )
        } else {
            callback(null, generate200Response(data))
        }
    });
}

function generate200Response(body) {
  return {
      "statusCode": 200,
      "headers": {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin" : "*", // Required for CORS support to work
          "Access-Control-Allow-Credentials" : true // Required for cookies, authorization headers with HTTPS 
      },
      "body": body,
      "isBase64Encoded": false
  }
}

function createNewRequest(item, context, callback) {
    const itemObj = JSON.parse(item);
    const id = uuid.v4()
    const rightNow = new Date();
    const currentDate = rightNow.toISOString().slice(0,10);//.replace(/-/g,"");

    const params = {
        TableName: tableName,
        Item: {
            request_id: id,
            request_type: itemObj.request_type,
            email: itemObj.email,
            details: itemObj.details,
            status: "open",
            creation_date: currentDate
        }
    }

    docClient.put(params,
        function(err, data) {
            if (err) {
                var errStr = {response: JSON.stringify(err, null, 2)};
                console.error(JSON.stringify(errStr));
                callback(errStr, null )
            }
            else {
                callback(null, generate200Response(data))
            }
        }
    );
}


function logInput(event) {
    // logging
    console.log('Logging input.');
    console.log(JSON.stringify(event));
    console.log('Body:', event.body);
    console.log('Headers:', event.headers);
    console.log('Http Method:', event.httpMethod);
    console.log('Params:', event.params);
    console.log('Query:', event.query);
    console.log('Request Type:', event.reqType);
    console.log('Path: ', event.path)
    // context.succeed(event);
}