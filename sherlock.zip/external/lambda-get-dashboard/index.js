const AWS = require('aws-sdk');
var path = require('path');

const esDomain = {
    endpoint: 'https://vpc-edw-sherlock-web-app-es-mqgvprzwhocqeerbldp2mdsqve.us-east-1.es.amazonaws.com',
    region: 'us-east-1',
    index: 'dashboards',
    doctype: 'dashboard'
};
const endpoint =  new AWS.Endpoint(esDomain.endpoint);
var creds = new AWS.EnvironmentCredentials('AWS');

exports.handler = function(event, context, callback) {
  console.log('Received event: ', JSON.stringify(event, null, 2));
	logInput(event);
	// Strip any leading slashes including the /dashboards/
	// if (event.resourcePath.charAt(0) == "/")
	var marker = event.path.lastIndexOf("/");	
	var resource = event.path.substr(marker+1);
	console.log('resource - ', resource);

	switch(resource) {
	    case 'dashboards':
				if (event.httpMethod === 'GET') {
					getAllDashboards(context, callback);
				}
				else if (event.httpMethod === 'POST') {
					const doc = event.body;
					addDocumentToES(JSON.stringify(doc), context, callback);
				}
        break;
	    case 'search':
		    const text = event.queryStringParameters.q;
				searchForDashboards(text, context, callback);
        break;

      case 'lens':
        const name = event.queryStringParameters.name;
        const lens = event.queryStringParameters.lens;
        const ring1 = event.queryStringParameters.ring1;
        const ring2 = event.queryStringParameters.ring2;
        const ring3 = event.queryStringParameters.ring3;
        searchDashboardsByLens(context, callback, name, lens, ring1, ring2, ring3);
        break;

	    default:
	        callback('Method not supported yet.', null)
	}
};

function searchForDashboards(searchText, context, callback) {
  var req = new AWS.HttpRequest(endpoint);
  req.method = 'GET';
  req.path = path.join('/', esDomain.index, esDomain.doctype, '_search', '?q='+searchText+"&size=100");
  req.region = esDomain.region;
  req.body = '';
  req.headers['presigned-expires'] = false;
  req.headers['Host'] = endpoint.host;
  req.headers['Content-Type'] = 'application/json';

  // // Sign the request (Sigv4)
  // var signer = new AWS.Signers.V4(req, 'es');
  // signer.addAuthorization(creds, new Date());

  // Post document to ES
  var send = new AWS.NodeHttpClient();
  send.handleRequest(req, null, function(httpResp) {
      var body = '';
      httpResp.on('data', function (chunk) {
          body += chunk;
      });
      httpResp.on('end', function (chunk) {
      	callback(null, generate200Response(body) )
      });
  }, function(err) {
      console.error('Error: ' + err);
      callback(err, null)
  });
}

function generate200Response(body) {
  return {
      "statusCode": 200,
      "headers": {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin" : "*", // Required for CORS support to work
          "Access-Control-Allow-Credentials" : true // Required for cookies, authorization headers with HTTPS 
      },
      "body": body,
      "isBase64Encoded": false
  }
}

function searchDashboardsByLens(context, callback, name, lens, ring1, ring2, ring3) {
  const queryBody = ring3 ? 
  ({
    query: {
      bool: {
        should: [{
          match: {
            ring3: ring3
          }
        }]
      }
    }
  })
  :
  ({
    query: {
      bool: {
        should: [{
          match: {
            lens: lens
          }
        }]
      }
    }
  });


  var req = new AWS.HttpRequest(endpoint);
  req.method = 'POST';
  req.path = path.join('/', esDomain.index, esDomain.doctype, '_search?size=100');
  req.region = esDomain.region;
  req.body = JSON.stringify(queryBody);
  req.headers['presigned-expires'] = false;
  req.headers['Host'] = endpoint.host;
  req.headers['Content-Type'] = 'application/json';

console.log(JSON.stringify(queryBody))

  // Sign the request (Sigv4)
  // var signer = new AWS.Signers.V4(req, 'es');
  // signer.addAuthorization(creds, new Date());

  // Post document to ES
  var send = new AWS.NodeHttpClient();
  send.handleRequest(req, null, function(httpResp) {
      var body = '';
      httpResp.on('data', function (chunk) {
          body += chunk;
      });
      httpResp.on('end', function (chunk) {
        callback(null, generate200Response(body) )
      });
  }, function(err) {
      console.log('Error: ' + err);
      callback(err, null)
  });
}




function getAllDashboards(context, callback) {
  var req = new AWS.HttpRequest(endpoint);
  req.method = 'GET';
  req.path = path.join('/', esDomain.index, esDomain.doctype, '_search', '?size=25');
  req.region = esDomain.region;
  req.body = '';
  req.headers['presigned-expires'] = false;
  req.headers['Host'] = endpoint.host;
  req.headers['Content-Type'] = 'application/json';

  // Sign the request (Sigv4)
  // var signer = new AWS.Signers.V4(req, 'es');
  // signer.addAuthorization(creds, new Date());

  // Post document to ES
  var send = new AWS.NodeHttpClient();
  send.handleRequest(req, null, function(httpResp) {
      var body = '';
      httpResp.on('data', function (chunk) {
          body += chunk;
      });
      httpResp.on('end', function (chunk) {
        callback(null, generate200Response(body) )
      });
  }, function(err) {
      console.log('Error: ' + err);
      callback(err, null)
  });
}

function addDocumentToES(doc, context, callback) {
  var req = new AWS.HttpRequest(endpoint);
  req.method = 'POST';
  req.path = path.join('/', esDomain.index, esDomain.doctype);
  req.region = esDomain.region;
  req.body = doc;
  req.headers['presigned-expires'] = false;
  req.headers['Host'] = endpoint.host;
  req.headers['Content-Type'] = 'application/json';

  // Sign the request (Sigv4)
  // var signer = new AWS.Signers.V4(req, 'es');
  // signer.addAuthorization(creds, new Date());

  // Post document to ES
  var send = new AWS.NodeHttpClient();
  send.handleRequest(req, null, function(httpResp) {
      var body = '';
      httpResp.on('data', function (chunk) {
          body += chunk;
      });
      httpResp.on('end', function (chunk) {
        callback(null, generate200Response(body) )
      });
  }, function(err) {
      console.log('Error: ' + err);
      callback(err, null)
  });
}

function logInput(event) {
	console.log('Logging input.');
	console.log('Body:', event.body);
	console.log('Headers:', event.headers);
	console.log('Method:', event.httpMethod);
	console.log('Params:', event.params);
	console.log('Query:', event.query);
	console.log('resourcePath: ', event.path)
}
