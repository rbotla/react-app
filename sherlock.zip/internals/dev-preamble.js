__webpack_public_path__ = window.location.protocol + '//' + window.location.host + '/';
